"""Exact truncated modular series arithmetic compatible with Fable's Ser interface."""

import operator

import numpy as np

try:
    from gmpy2 import mpz
except ImportError:
    mpz = None


class PackedSer:
    """Multiply rectangular series by byte-lane Kronecker substitution, without carries."""

    def __init__(self, variables, order, modulus, backend="auto"):
        self.c = operator.index(variables)
        self.E = operator.index(order)
        self.mod = operator.index(modulus)
        if self.c not in (1, 2) or self.E < 2 or self.mod < 2:
            raise ValueError("Require one or two variables, order >= 2, and modulus >= 2")
        if backend not in ("auto", "python", "gmpy2"):
            raise ValueError("Unknown integer backend")
        if backend == "gmpy2" and mpz is None:
            raise RuntimeError("The requested gmpy2 backend is not installed")
        self.integer_type = mpz if mpz is not None and backend != "python" else int
        self.backend = "python" if self.integer_type is int else "gmpy2"
        self.dt = np.int64 if self.E**self.c * self.mod**2 < 2**62 else object
        self.shape = (self.E,) * self.c
        self.stride = 2 * self.E - 1
        coefficient_bound = self.E**self.c * (self.mod - 1)**2
        self.lane_bytes = (coefficient_bound.bit_length() + 7) // 8
        if self.c == 1:
            self.offsets = tuple(index * self.lane_bytes for index in range(self.E))
        else:
            self.offsets = tuple((row * self.stride + column) * self.lane_bytes
                                 for row in range(self.E) for column in range(self.E))
        self.input_bytes = self.offsets[-1] + self.lane_bytes
        self.output_bytes = 2 * self.input_bytes

    def zero(self):
        return np.zeros(self.shape, dtype=self.dt)

    def const(self, value):
        result = self.zero()
        result[(0,) * self.c] = operator.index(value) % self.mod
        return result

    def var(self, variable, coeff=1):
        variable = operator.index(variable)
        if not 0 <= variable < self.c:
            raise ValueError("Variable index out of range")
        result = self.zero()
        index = [0] * self.c
        index[variable] = 1
        result[tuple(index)] = operator.index(coeff) % self.mod
        return result

    def add(self, left, right):
        return (left + right) % self.mod

    def sub(self, left, right):
        return (left - right) % self.mod

    def scal(self, scalar, value):
        return (operator.index(scalar) % self.mod) * value % self.mod

    def pack(self, value):
        value = np.asarray(value)
        if value.shape != self.shape:
            raise ValueError("Series has the wrong shape")
        packed = bytearray(self.input_bytes)
        lane_bytes = self.lane_bytes
        for offset, coefficient in zip(self.offsets, value.flat):
            coefficient = operator.index(coefficient) % self.mod
            if coefficient:
                packed[offset:offset + lane_bytes] = coefficient.to_bytes(lane_bytes, "little")
        return self.integer_type.from_bytes(packed, "little")

    def mul(self, left, right):
        packed_left = self.pack(left)
        if not packed_left:
            return self.zero()
        packed_right = packed_left if right is left else self.pack(right)
        if not packed_right:
            return self.zero()
        encoded = (packed_left * packed_right).to_bytes(self.output_bytes, "little")
        lane_bytes = self.lane_bytes
        values = [int.from_bytes(encoded[offset:offset + lane_bytes], "little") % self.mod
                  for offset in self.offsets]
        return np.asarray(values, dtype=self.dt).reshape(self.shape)

    def truncate_total(self, value):
        if self.c == 1:
            return value
        result = value.copy()
        for row in range(self.E):
            result[row, self.E - row:] = 0
        return result

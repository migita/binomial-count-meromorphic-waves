"""Combine trusted independent audit bounds without adding overlapping residue fibres."""

import argparse
from datetime import datetime, timezone
import hashlib
import itertools
import json
from pathlib import Path

from codex_verify_dvr_batches import read_data


MATHEMATICAL_CHECKERS = ("codex_dvr_branch_certificate.py", "codex_dvr_refinement.py",
                         "codex_finite_algebra_certificate.py")


def certified_count(row):
    if row["status"] != "certified":
        return 0
    check = row["check"]
    branches = check["branches"]
    if not check["certified"] or not branches or not all(item["hensel_certified"] for item in branches):
        raise ValueError("A claimed certified row has no complete Hensel certificate")
    if any(item["degree"] < 1 for item in branches):
        raise ValueError("Field degrees must be positive")
    total = sum(item["degree"] for item in branches)
    if total != check["simple_points_certified"]:
        raise ValueError("Reported count differs from the sum of certified field degrees")
    checks = check["separation_checks"]
    if not all(item["passed"] for item in checks):
        raise ValueError("A certified row contains a failed separation check")
    discs = {tuple(item["branches"]) for item in checks if item["kind"] == "discriminant"}
    pairs = {tuple(item["branches"]) for item in checks if item["kind"] == "resultant"}
    if discs != {(index,) for index in range(len(branches))}:
        raise ValueError("Some field-generation discriminants are missing")
    if pairs != set(itertools.combinations(range(len(branches)), 2)):
        raise ValueError("Some pairwise orbit-separation checks are missing")
    return total


def merge_reports(named_reports, expected_labels):
    if not named_reports:
        raise ValueError("At least one independent audit is required")
    expected_labels = {tuple(label) for label in expected_labels}
    baseline = named_reports[0][1]
    metadata = (baseline["p"], baseline["prime"], baseline["stage_sha256"])
    checker_hashes = {name: baseline["checker_sha256"][name] for name in MATHEMATICAL_CHECKERS}
    seen_all, chosen, appearances, presentation_counts = set(), {}, {}, {}
    for source, report in named_reports:
        if (report["p"], report["prime"], report["stage_sha256"]) != metadata:
            raise ValueError("Do not merge different orders, primes, or exact input systems")
        if {name: report["checker_sha256"][name] for name in MATHEMATICAL_CHECKERS} != checker_hashes:
            raise ValueError("Mathematical checker versions differ; review or replay before merging")
        if report["expected_corank_two_special_points"] != len(expected_labels):
            raise ValueError("The expected residue-label count does not match the stage")
        seen_report = set()
        for index, row in enumerate(report["results"]):
            label = tuple(row["point"])
            if label not in expected_labels or label in seen_report:
                raise ValueError("Unexpected or duplicate residue label within one audit")
            seen_report.add(label)
            seen_all.add(label)
            appearances[label] = appearances.get(label, 0) + 1
            claimed = row.get("claimed_presentation_count")
            if claimed is not None:
                presentation_counts.setdefault(label, set()).add(claimed)
            count = certified_count(row)
            if count and count > chosen.get(label, {}).get("simple_points_certified", 0):
                chosen[label] = {
                    "point": list(label), "simple_points_certified": count,
                    "audit_source": source, "audit_record": index,
                    "candidate_source": row.get("source"),
                    "claimed_presentation_count": claimed,
                    "matches_claimed_presentation_count": count == claimed,
                }
    selected = [chosen[label] for label in sorted(chosen)]
    return {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "p": baseline["p"], "prime": baseline["prime"], "stage_sha256": baseline["stage_sha256"],
        "mathematical_checker_sha256": checker_hashes,
        "expected_corank_two_special_points": len(expected_labels),
        "reviewed_special_points": len(seen_all), "certified_special_points": len(chosen),
        "complete_input_coverage": seen_all == expected_labels,
        "overlapping_residue_labels_not_added_twice": sum(count > 1 for count in appearances.values()),
        "simple_points_certified_lower_bound": sum(row["simple_points_certified"] for row in selected),
        "selected_certificates_matching_claimed_presentation_counts":
            sum(row["matches_claimed_presentation_count"] for row in selected),
        "labels_without_a_certified_bound": [list(label) for label in sorted(expected_labels - chosen.keys())],
        "presentation_count_disagreements": [{"point": list(label), "claims": sorted(counts)}
                                              for label, counts in sorted(presentation_counts.items()) if len(counts) > 1],
        "selected": selected,
        "interpretation": "Bookkeeping over already trusted independent certificates, not a fresh equation-level proof. Selects one strongest bound per residue label; overlapping partial bounds are not added. Presentation counts are not assumed to be true local lengths. No global or all-order exhaustion claim is made.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reports", nargs="+", type=Path)
    parser.add_argument("--stage", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    arguments = parser.parse_args()
    named_reports, sources = [], []
    for path in arguments.reports:
        raw = path.read_bytes()
        named_reports.append((str(path), json.loads(raw)))
        sources.append({"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()})
    stage_path = arguments.stage or Path(named_reports[0][1]["stage_source"])
    stage, digest = read_data(stage_path)
    if digest != named_reports[0][1]["stage_sha256"]:
        parser.error("The stage file changed since the audit")
    expected = [point for point, corank, presentations in stage["singular"] if corank == 2]
    result = merge_reports(named_reports, expected)
    result.update(stage_source=str(stage_path), source_audits=sources)
    arguments.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ("selected", "labels_without_a_certified_bound")}, indent=2))


if __name__ == "__main__":
    main()

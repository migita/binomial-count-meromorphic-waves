import random
import unittest

import sympy as sp

from codex_finite_algebra_certificate import FiniteAlgebra, certify


class CertificateChecks(unittest.TestCase):
    def test_repeated_root_false_positives_are_rejected(self):
        for prime in (5, 13, 19):
            defining = [prime**3, -(prime + prime**2), 1]
            result = certify(defining, prime, 16, [[0, 1]], [{(2,): (1, 1)}])
            self.assertFalse(result["certified"])
            self.assertFalse(result["hensel_certified"])
            self.assertEqual(result["norm_jacobian_valuation"], 3)
            self.assertEqual(result["residual_valuation_lower_bound"], 1)

    def test_weak_hensel_equality_is_rejected(self):
        result = certify([0, 1], 5, 16, [[5]], [{(2,): (1, 1), (0,): (50, 1)}])
        self.assertFalse(result["certified"])
        self.assertEqual(result["reason"], "strict_coefficient_norm_hensel_bound_not_met")

    def test_two_simple_ramified_residue_roots(self):
        for prime in (5, 13, 19):
            defining = [2 * prime**2, -3 * prime, 1]
            equation = {(2,): (1, 1), (1,): (-3 * prime, 1), (0,): (2 * prime**2, 1)}
            result = certify(defining, prime, 16, [[0, 1]], [equation])
            self.assertTrue(result["certified"])
            self.assertEqual(result["simple_root_embeddings"], 2)
            self.assertEqual(result["norm_jacobian_valuation"], 2)
            self.assertEqual(result["common_residue"], [0])

    def test_nonmaximal_order_is_not_itself_an_obstruction(self):
        result = certify([-25, 0, 0, 1], 5, 24, [[0, 1]],
                         [{(3,): (1, 1), (0,): (-25, 1)}])
        self.assertTrue(result["certified"])
        self.assertEqual(result["simple_root_embeddings"], 3)
        self.assertEqual(result["norm_jacobian_valuation"], 4)

    def test_unramified_extension_roots_in_a_nonmaximal_order(self):
        result = certify([50, 0, 1], 5, 16, [[0, 1]],
                         [{(2,): (1, 1), (0,): (50, 1)}])
        self.assertTrue(result["certified"])
        self.assertEqual(result["simple_root_embeddings"], 2)

    def test_precision_threshold_is_strict(self):
        defining = [50, -15, 1]
        equation = {(2,): (1, 1), (1,): (-15, 1), (0,): (50, 1)}
        self.assertFalse(certify(defining, 5, 4, [[0, 1]], [equation])["certified"])
        self.assertTrue(certify(defining, 5, 5, [[0, 1]], [equation])["certified"])

    def test_lifting_without_separation_does_not_overcount(self):
        for defining in ([50, -15, 1], [0, 0, 1]):
            result = certify(defining, 5, 16, [[1]], [{(1,): (1, 1), (0,): (-1, 1)}])
            self.assertTrue(result["hensel_certified"])
            self.assertFalse(result["certified"])
            self.assertEqual(result["simple_root_embeddings"], 0)

    def test_multivariate_exact_system(self):
        equations = [
            {(2, 0): (1, 1), (1, 0): (-15, 1), (0, 0): (50, 1)},
            {(0, 1): (1, 1), (1, 0): (-1, 1)},
        ]
        result = certify([50, -15, 1], 5, 16, [[0, 1], [0, 1]], equations)
        self.assertTrue(result["certified"])
        self.assertEqual(result["common_residue"], [0, 0])

    def test_separator_may_need_more_than_one_coordinate(self):
        coordinate = sp.Symbol("coordinate")
        defining = sp.Poly(sp.prod(coordinate - root for root in range(4)), coordinate)
        precision, prime = 12, 5
        point = []
        for values in ([0, 0, 1, 1], [0, 1, 0, 1]):
            polynomial = sp.Poly(sp.interpolate(list(enumerate(values)), coordinate), coordinate)
            coefficients = []
            for power in range(4):
                numerator, denominator = polynomial.nth(power).as_numer_denom()
                coefficients.append(int(numerator) * pow(int(denominator), -1, prime**precision) % prime**precision)
            point.append(coefficients)
        equations = [{(2, 0): (1, 1), (1, 0): (-1, 1)},
                     {(0, 2): (1, 1), (0, 1): (-1, 1)}]
        result = certify(list(reversed(defining.all_coeffs())), prime, precision, point, equations)
        self.assertTrue(result["certified"])
        self.assertEqual(result["simple_root_embeddings"], 4)
        self.assertEqual(result["separator"], [1, 2])

    def test_zero_jacobian_and_empty_terms_are_safe(self):
        result = certify([0, 1], 5, 12, [[0], [0]], [{}, {}])
        self.assertFalse(result["certified"])
        self.assertIsNone(result["norm_jacobian_valuation"])

    def test_nonintegral_equations_and_inexact_input_rejected(self):
        with self.assertRaises(ValueError):
            certify([0, 1], 5, 12, [[0]], [{(1,): (1, 5)}])
        with self.assertRaises(TypeError):
            certify([0, 1], 5, 12, [[0.5]], [{(1,): (1, 1)}])

    def test_division_free_determinants_against_symbolic_reference(self):
        generator = random.Random(260902)
        coordinate = sp.Symbol("coordinate")
        for degree in (1, 2, 3):
            defining = [-3] + [0] * (degree - 1) + [1]
            algebra = FiniteAlgebra(defining, 11, 4)
            for size in (1, 2, 3, 4):
                matrix = [[algebra.element([generator.randint(-3, 3) for power in range(degree)])
                           for column in range(size)] for row in range(size)]
                symbolic = sp.Matrix([[sum(value * coordinate**power for power, value in enumerate(entry))
                                       for entry in row] for row in matrix])
                remainder = sp.Poly(sp.rem(symbolic.det(), coordinate**degree - 3, coordinate), coordinate)
                expected = algebra.element([remainder.nth(power) for power in range(degree)])
                self.assertEqual(algebra.determinant(matrix), expected)


if __name__ == "__main__":
    unittest.main(verbosity=2)

"""Precision-aware Newton-polygon candidate descent over arbitrary tame local fields."""

import argparse
from fractions import Fraction
import json
import math
import sys

from flint import fq_default_poly_ctx

from codex_dvr_branch_certificate import DVRField
from codex_finite_algebra_certificate import integer
from codex_tame_fields import (
    FieldEmbedding, field_definition, from_lfield, polynomial_value, residue_coefficients,
    residue_context, ring_power, tame_extension, unit_inverse,
)


def uniformizer_division(field, value, exponent):
    """Divide an integral element by pi^exponent; callers must reduce the precision bound by exponent."""
    exponent = integer(exponent)
    if exponent < 0:
        return field.multiply(value, ring_power(field, field.uniformizer(), -exponent))
    quotient, remainder = divmod(exponent, field.ramification)
    if exponent >= field.ramification * field.precision:
        raise ValueError("Uniformizer division exhausts the stored precision")
    powers = {power: ring_power(field.unramified, field.unit, -power)
              for power in {quotient, quotient + int(remainder != 0)}}
    output = [[0] * field.residue_degree for index in range(field.ramification)]
    for row in range(field.ramification):
        power = quotient + int(row < remainder)
        divisor = field.prime**power
        coefficients = value[row * field.residue_degree:(row + 1) * field.residue_degree]
        if any(coefficient % divisor for coefficient in coefficients):
            raise ValueError("An alleged integral normalized coefficient is not divisible")
        divided = tuple(coefficient // divisor for coefficient in coefficients)
        output[(row - remainder) % field.ramification] = field.unramified.multiply(divided, powers[power])
    return field.element(output)


def truncate_valuation(field, value, precision):
    result = []
    for row in range(field.ramification):
        digits = max(0, min(field.precision, (precision - row + field.ramification - 1) // field.ramification))
        modulus = field.prime**digits
        result.extend(coefficient % modulus for coefficient in value[row * field.residue_degree:(row + 1) * field.residue_degree])
    return field.element(result)


def invert_dvr_unit(field, value):
    if field.valuation(value) != 0:
        raise ValueError("A unit is required")
    initial = unit_inverse(field.unramified, value[:field.residue_degree])
    result = field.element(initial)
    for iteration in range((field.ramification * field.precision).bit_length() + 1):
        result = field.multiply(result, field.add(field.scalar(2), field.negate(field.multiply(value, result))))
    if field.multiply(value, result) != field.one:
        raise ArithmeticError("DVR unit inverse failed")
    return result


def normalized_translation(field, coefficients, seed, dividing_valuation):
    output = [field.zero for coefficient in coefficients]
    power = field.one
    for exponent, coefficient in enumerate(coefficients):
        term = field.multiply(coefficient, power)
        for index in range(exponent + 1):
            output[index] = field.add(output[index], field.scale(math.comb(exponent, index), term))
        power = field.multiply(power, seed)
    return [uniformizer_division(field, coefficient, dividing_valuation) for coefficient in output]


def simple_zero_lift(field, coefficients, precision):
    derivative = [field.scale(index, coefficient) for index, coefficient in enumerate(coefficients)][1:]
    value = field.zero
    if field.valuation(coefficients[0]) < 1:
        raise ArithmeticError("The selected edge root does not give a zero residue")
    for iteration in range(precision.bit_length() + 2):
        residual = polynomial_value(field, coefficients, value)
        if field.valuation(residual) >= precision:
            return truncate_valuation(field, value, precision)
        slope = polynomial_value(field, derivative, value)
        correction = field.multiply(residual, invert_dvr_unit(field, slope))
        value = truncate_valuation(field, field.add(value, field.negate(correction)), precision)
    raise ArithmeticError("Unit-derivative Newton lifting did not reach the known precision")


def identity_embedding(field):
    zeta = field.element([0, 1]) if field.residue_degree > 1 else field.scalar(-field.unramified.defining[0])
    return FieldEmbedding(field, field, zeta, field.uniformizer())


def lower_hull(points):
    hull = []
    for point in points:
        while len(hull) >= 2:
            first, second = hull[-2:]
            if ((second[1] - first[1]) * (point[0] - second[0])
                    >= (point[1] - second[1]) * (second[0] - first[0])):
                hull.pop()
            else:
                break
        hull.append(point)
    return hull


def edge_factorization(field, coefficients, valuations, first, second):
    initial_index, initial_value = first
    final_index, final_value = second
    slope = Fraction(initial_value - final_value, final_index - initial_index)
    numerator, denominator = slope.numerator, slope.denominator
    context = residue_context(field.prime, field.unramified.defining)
    polynomial_context = fq_default_poly_ctx(context)
    terms = [context.zero() for index in range((final_index - initial_index) // denominator + 1)]
    for index in range(initial_index, final_index + 1, denominator):
        position = (index - initial_index) // denominator
        expected = initial_value - numerator * position
        if valuations[index] == expected:
            normalized = uniformizer_division(field, coefficients[index], expected)
            terms[position] = context([coefficient % field.prime for coefficient in normalized[:field.residue_degree]])
    polynomial = polynomial_context(terms)
    content, factors = polynomial.factor()
    reconstructed = polynomial_context(content)
    for factor, multiplicity in factors:
        reconstructed *= factor**multiplicity
    if reconstructed != polynomial:
        raise ArithmeticError("Finite-field factorization did not reconstruct the edge polynomial")
    encoded = [([list(residue_coefficients(coefficient)) for coefficient in factor.coeffs()], int(multiplicity))
               for factor, multiplicity in factors]
    return numerator, denominator, encoded


def descend_candidates(coefficients, base, known_valuation=None, maximum_depth=12, maximum_degree=128, depth=0):
    """Return candidates and explicit unresolved cases, never a substitute for exact-equation certification."""
    coefficients = [base.element(coefficient) for coefficient in coefficients]
    if not coefficients:
        raise ValueError("A nonempty coefficient list is required")
    cap = base.ramification * base.precision
    known = cap if known_valuation is None else integer(known_valuation)
    if not 1 <= known <= cap:
        raise ValueError("Known valuation precision must be positive and within the stored precision")
    valuations = [min(base.valuation(coefficient), known) for coefficient in coefficients]
    minimum = min(valuations)
    result = {"branches": [], "flags": [], "visible_small_root_length": None,
              "covered_candidate_degree": 0, "candidate_exhaustion": False, "candidate_only": True}
    if minimum == known:
        result["flags"].append({"reason": "polynomial_zero_to_known_precision", "depth": depth})
        return result
    length = valuations.index(minimum)
    result["visible_small_root_length"] = length
    if length == 0:
        result["candidate_exhaustion"] = True
        return result
    if depth >= maximum_depth:
        result["flags"].append({"reason": "depth_limit", "depth": depth, "unresolved_degree": length})
        return result
    hull = lower_hull([(index, valuations[index]) for index in range(length + 1)])
    for first, second in zip(hull, hull[1:]):
        width = second[0] - first[0]
        if first[1] >= known:
            result["flags"].append({"reason": "unknown_coefficient_valuation", "index": first[0],
                                    "depth": depth, "unresolved_degree": width})
            continue
        if first[1] <= second[1]:
            continue
        numerator, denominator, factors = edge_factorization(base, coefficients, valuations, first, second)
        for factor, multiplicity in factors:
            relative_degree = denominator * (len(factor) - 1)
            frame = {"slope": [numerator, denominator], "factor": factor, "multiplicity": multiplicity,
                     "edge": [list(first), list(second)], "base_field": field_definition(base), "depth": depth}
            expected_degree = relative_degree * multiplicity
            if denominator % base.prime == 0 or base.ramification % base.prime == 0:
                result["flags"].append(dict(frame, reason="wild_ramification_not_supported", unresolved_degree=expected_degree))
                continue
            if base.degree * relative_degree > maximum_degree:
                result["flags"].append(dict(frame, reason="field_degree_limit", unresolved_degree=expected_degree))
                continue
            height = denominator * first[1] + numerator * first[0]
            remaining = known * denominator - height
            if remaining < 1:
                result["flags"].append(dict(frame, reason="precision_exhausted_by_normalization",
                                            unresolved_degree=expected_degree))
                continue
            extension = tame_extension(base, numerator, denominator, factor)
            field, seed = extension.field, extension.leading_root
            embedded = [extension.embedding.apply(coefficient) for coefficient in coefficients]
            translated = normalized_translation(field, embedded, seed, height)
            frame["extension_field"] = field_definition(field)
            frame["remaining_valuation_precision"] = remaining
            residue_length = next((index for index, coefficient in enumerate(translated)
                                   if field.valuation(coefficient) == 0), None)
            if residue_length != multiplicity:
                result["flags"].append(dict(frame, reason="edge_multiplicity_not_preserved", unresolved_degree=expected_degree))
                continue
            if multiplicity == 1:
                correction = simple_zero_lift(field, translated, remaining)
                root = field.multiply(seed, field.add(field.one, correction))
                branch = {"field": field, "root": root, "embedding": extension.embedding,
                          "relative_degree": relative_degree, "absolute_degree": field.degree,
                          "root_precision": min(field.ramification * field.precision, remaining + numerator),
                          "chain": [frame], "candidate_only": True}
                result["branches"].append(branch)
            else:
                child = descend_candidates(translated, field, remaining, maximum_depth, maximum_degree, depth + 1)
                for flag in child["flags"]:
                    result["flags"].append(dict(flag, parent_chain=[frame] + flag.get("parent_chain", []),
                                                unresolved_degree=relative_degree * flag.get("unresolved_degree", multiplicity)))
                for branch in child["branches"]:
                    final_field = branch["field"]
                    image_seed = branch["embedding"].apply(seed)
                    root = final_field.multiply(image_seed, final_field.add(final_field.one, branch["root"]))
                    embedding = extension.embedding.then(branch["embedding"])
                    result["branches"].append({
                        "field": final_field, "root": root, "embedding": embedding,
                        "relative_degree": relative_degree * branch["relative_degree"],
                        "absolute_degree": final_field.degree,
                        "root_precision": min(final_field.ramification * final_field.precision,
                                              final_field.valuation(image_seed) + branch["root_precision"]),
                        "chain": [frame] + branch["chain"], "candidate_only": True,
                    })
    result["covered_candidate_degree"] = sum(branch["relative_degree"] for branch in result["branches"])
    result["candidate_exhaustion"] = not result["flags"] and result["covered_candidate_degree"] == length
    if not result["flags"] and not result["candidate_exhaustion"]:
        result["flags"].append({"reason": "candidate_degree_accounting_mismatch", "depth": depth})
    return result


def array_coordinates(field, value):
    return [list(value[index:index + field.residue_degree]) for index in range(0, field.degree, field.residue_degree)]


def encode_report(report):
    encoded = {key: value for key, value in report.items() if key != "branches"}
    encoded["branches"] = []
    for branch in report["branches"]:
        field, embedding = branch["field"], branch["embedding"]
        encoded["branches"].append({
            **{key: value for key, value in branch.items() if key not in ("field", "root", "embedding")},
            "field_def": field_definition(field), "root": array_coordinates(field, branch["root"]),
            "base_generator_image": array_coordinates(field, embedding.zeta_image),
            "base_uniformizer_image": array_coordinates(field, embedding.uniformizer_image),
            "base_basis_images": [array_coordinates(field, value) for value in embedding.basis_images],
        })
    return encoded


def branches_over_field(coefficients, base, known_valuation=None, **options):
    """LField-compatible report with field/root objects and an embed_base callable for every branch."""
    if isinstance(base, DVRField):
        return descend_candidates(coefficients, base, known_valuation, **options)
    import numpy as np
    model = from_lfield(base)
    values = [model.element(coefficient.tolist()) for coefficient in coefficients]
    report = descend_candidates(values, model, known_valuation, **options)
    for branch in report["branches"]:
        target, embedding = branch["field"], branch["embedding"]
        branch["field"] = type(base)(target.prime, target.precision, target.unramified.defining, 1,
                                     target.ramification, target.unit)
        branch["root"] = np.asarray(array_coordinates(target, branch["root"]), dtype=object)
        branch["embed_base"] = lambda value, mapping=embedding, target=target: np.asarray(
            array_coordinates(target, mapping.apply(value.tolist())), dtype=object
        )
    return report


def process_request(request):
    definition = request["field_def"]
    field = DVRField(definition["ell"], definition["M"], definition["m"], definition["b"], definition["u"])
    return encode_report(descend_candidates(request["coefficients"], field,
                                           known_valuation=request.get("known_valuation"),
                                           maximum_depth=request.get("maximum_depth", 12),
                                           maximum_degree=request.get("maximum_degree", 128)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json-lines", action="store_true")
    arguments = parser.parse_args()
    requests = (json.loads(line) for line in sys.stdin if line.strip()) if arguments.json_lines else [json.load(sys.stdin)]
    for request in requests:
        try:
            result = process_request(request)
        except (ArithmeticError, ValueError, TypeError, KeyError) as error:
            result = {"candidate_only": True, "branches": [], "candidate_exhaustion": False, "error": str(error)}
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()

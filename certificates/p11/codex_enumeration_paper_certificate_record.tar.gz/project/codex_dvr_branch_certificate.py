"""Independent exact-equation, field-degree, and disjointness certificates for local branches."""

import itertools

import sympy as sp

from codex_finite_algebra_certificate import FiniteAlgebra, evaluate_system, integer, normalize_equations


class DVRField(FiniteAlgebra):
    """The integral basis zeta^j*pi^i, with m(zeta)=0 and pi^b=prime*u(zeta)."""

    def __init__(self, prime, precision, unramified, ramification, unit):
        self.unramified = FiniteAlgebra(unramified, prime, precision)
        self.prime = self.unramified.prime
        self.precision = self.unramified.precision
        self.modulus = self.unramified.modulus
        self.ramification = integer(ramification)
        if self.ramification < 1:
            raise ValueError("Positive ramification degree required")
        symbol = sp.Symbol("zeta")
        polynomial = sp.Poly.from_list(list(reversed(self.unramified.defining)), symbol, modulus=self.prime)
        if not polynomial.is_irreducible:
            raise ValueError("The unramified polynomial must be irreducible modulo the prime")
        self.residue_degree = self.unramified.degree
        self.unit = self.unramified.element(unit)
        if self.unramified.coefficient_valuation(self.unit) != 0:
            raise ValueError("The Eisenstein constant factor must be a unit")
        self.degree = self.ramification * self.residue_degree
        self.zero = (0,) * self.degree
        self.one = (1,) + (0,) * (self.degree - 1)
        self.twist = self.unramified.scale(self.prime, self.unit)

    def element(self, coefficients):
        coefficients = list(coefficients)
        if coefficients and isinstance(coefficients[0], (list, tuple)):
            if len(coefficients) != self.ramification or any(len(row) != self.residue_degree for row in coefficients):
                raise ValueError("Wrong shape for integral-basis coordinates")
            coefficients = list(itertools.chain.from_iterable(coefficients))
        if len(coefficients) > self.degree:
            raise ValueError("Too many integral-basis coefficients")
        return tuple([integer(value) % self.modulus for value in coefficients]
                     + [0] * (self.degree - len(coefficients)))

    def multiply(self, left, right):
        if left == self.zero or right == self.zero:
            return self.zero
        width = self.residue_degree
        result = [[0] * width for row in range(self.ramification)]
        for first in range(self.ramification):
            left_row = left[first * width:(first + 1) * width]
            if not any(left_row):
                continue
            for second in range(self.ramification):
                right_row = right[second * width:(second + 1) * width]
                if not any(right_row):
                    continue
                product = self.unramified.multiply(left_row, right_row)
                row = first + second
                if row >= self.ramification:
                    product = self.unramified.multiply(product, self.twist)
                    row -= self.ramification
                result[row] = list(self.unramified.add(result[row], product))
        return tuple(itertools.chain.from_iterable(result))

    def valuation(self, value):
        bound = self.ramification * self.precision
        return min([bound] + [index // self.residue_degree
                             + self.ramification * self.integer_valuation(coefficient)
                             for index, coefficient in enumerate(value)])

    def uniformizer(self):
        if self.ramification == 1:
            return self.element(self.twist)
        return self.element([0] * self.residue_degree + [1])

    def characteristic_polynomial(self, value, symbol):
        coefficients = self.multiplication_matrix(value).charpoly(symbol).all_coeffs()
        return sp.Poly.from_list([integer(value) % self.modulus for value in coefficients], symbol, domain=sp.ZZ)


def prepare_branch(branch, equations):
    definition = branch["field_def"]
    field = DVRField(definition["ell"], definition["M"], definition["m"], definition["b"], definition["u"])
    point = [field.element(value) for value in branch["a_certified"]]
    if not point:
        raise ValueError("A nonempty point is required")
    normalized = normalize_equations(equations, len(point), field.prime)
    residuals, jacobian = evaluate_system(field, normalized, point)
    residual_valuation = min(field.valuation(value) for value in residuals)
    determinant_valuation = field.valuation(field.determinant(jacobian))
    cap = field.ramification * field.precision
    passed = determinant_valuation < cap and residual_valuation > 2 * determinant_valuation
    result = {
        "degree": field.degree, "prime": field.prime, "precision": field.precision,
        "ramification": field.ramification, "residue_degree": field.residue_degree,
        "residual_valuation_lower_bound": residual_valuation,
        "jacobian_valuation": determinant_valuation if determinant_valuation < cap else None,
        "hensel_certified": passed,
    }
    if passed:
        radius = residual_valuation - determinant_valuation
        result.update(correction_valuation_lower_bound=radius,
                      coefficient_precision_lower_bound=radius // field.ramification)
    return field, point, result


def default_separators(dimension):
    return ([tuple(int(index == coordinate) for index in range(dimension)) for coordinate in range(dimension)]
            + [tuple(base**index for index in range(dimension)) for base in (2, 3, 5)])


def separation_test(value, prime, precision, threshold, kind, indices):
    modulus = prime**precision
    reduced = integer(value) % modulus
    valuation = precision
    if reduced:
        valuation = 0
        while reduced % prime == 0:
            reduced //= prime
            valuation += 1
    return {
        "kind": kind, "branches": indices, "known_precision": precision,
        "valuation": valuation if valuation < precision else None,
        "valuation_lower_bound": valuation,
        "required_strict_upper_bound": threshold,
        "passed": valuation < threshold,
    }


def certify_branches(equations, branches, separators=None):
    """Count all field embeddings only after exact Hensel, primitive-value and disjointness checks."""
    if not branches:
        raise ValueError("At least one branch is required")
    prepared = [prepare_branch(branch, equations) for branch in branches]
    fields = [entry[0] for entry in prepared]
    points = [entry[1] for entry in prepared]
    branch_results = [entry[2] for entry in prepared]
    prime = fields[0].prime
    dimension = len(points[0])
    if any(field.prime != prime for field in fields) or any(len(point) != dimension for point in points):
        raise ValueError("Branches must solve the same system over one residue characteristic")
    result = {
        "certified": False, "simple_points_certified": 0,
        "claimed_total_field_degree": sum(field.degree for field in fields),
        "branches": branch_results,
    }
    if not all(entry["hensel_certified"] for entry in branch_results):
        result["reason"] = "strict_exact_equation_hensel_condition_not_met_for_every_branch"
        return result
    if separators is None:
        separators = default_separators(dimension)
    symbol = sp.Symbol("separating_value")
    best, tested = None, set()
    for weights in separators:
        weights = tuple(integer(weight) for weight in weights)
        if len(weights) != dimension:
            raise ValueError("Wrong separator dimension")
        if weights in tested:
            continue
        tested.add(weights)
        polynomials = []
        for field, point in zip(fields, points):
            value = field.zero
            for weight, coordinate in zip(weights, point):
                value = field.add(value, field.scale(weight, coordinate))
            polynomials.append(field.characteristic_polynomial(value, symbol))
        checks = []
        for index, (field, polynomial, branch_result) in enumerate(zip(fields, polynomials, branch_results)):
            checks.append(separation_test(
                polynomial.discriminant(), prime, field.precision,
                branch_result["coefficient_precision_lower_bound"], "discriminant", [index]
            ))
        for first, second in itertools.combinations(range(len(fields)), 2):
            common_precision = min(fields[first].precision, fields[second].precision)
            threshold = min(branch_results[first]["coefficient_precision_lower_bound"],
                            branch_results[second]["coefficient_precision_lower_bound"])
            checks.append(separation_test(polynomials[first].resultant(polynomials[second]), prime,
                                          common_precision, threshold, "resultant", [first, second]))
        failed = sum(not check["passed"] for check in checks)
        record = {
            "separator": list(weights), "separation_checks": checks,
            "characteristic_polynomials_descending": [[integer(value) for value in polynomial.all_coeffs()]
                                                       for polynomial in polynomials],
        }
        if best is None or failed < best[0]:
            best = (failed, record)
        if failed == 0:
            result.update(record)
            result.update(certified=True, simple_points_certified=sum(field.degree for field in fields),
                          reason="strict_hensel_stable_discriminants_and_pairwise_resultants")
            return result
    if best is not None:
        result.update(best[1])
    result["reason"] = "no_tested_separator_certifies_all_field_degrees_and_pairwise_disjointness"
    return result

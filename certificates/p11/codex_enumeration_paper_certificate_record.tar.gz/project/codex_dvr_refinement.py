"""Bounded candidate improvement; the independent exact certificate remains authoritative."""

import sympy as sp

from codex_dvr_branch_certificate import DVRField, certify_branches
from codex_finite_algebra_certificate import evaluate_system, integer, normalize_equations


class IntegralDivision:
    """Generate integral quotients through the regular representation, with a conservative precision loss."""

    def __init__(self, field, denominator):
        self.field = field
        matrix = field.multiplication_matrix(denominator)
        determinant = integer(matrix.det(method="domain-ge"))
        valuation = field.integer_valuation(determinant)
        if valuation >= field.precision:
            raise ValueError("Denominator norm is unresolved at the working precision")
        self.divisor = field.prime**valuation
        self.remaining_precision = field.precision - valuation
        self.remaining_modulus = field.prime**self.remaining_precision
        self.inverse_unit = pow((determinant // self.divisor) % self.remaining_modulus, -1, self.remaining_modulus)
        self.adjugate = matrix.adjugate()

    def divide(self, numerator):
        transformed = self.adjugate * sp.Matrix(numerator)
        if any(integer(value) % self.divisor for value in transformed):
            raise ValueError("The proposed Newton correction is not integral")
        return self.field.element([(integer(value) // self.divisor) * self.inverse_unit % self.remaining_modulus
                                   for value in transformed])


def refine_once(equations, branch):
    definition = branch["field_def"]
    field = DVRField(definition["ell"], definition["M"], definition["m"], definition["b"], definition["u"])
    point = [field.element(value) for value in branch["a_certified"]]
    normalized = normalize_equations(equations, len(point), field.prime)
    residuals, jacobian = evaluate_system(field, normalized, point)
    determinant = field.determinant(jacobian)
    division = IntegralDivision(field, determinant)
    updated = []
    for coordinate in range(len(point)):
        substituted = [[residuals[row] if column == coordinate else entry
                        for column, entry in enumerate(jacobian[row])] for row in range(len(point))]
        numerator = field.determinant(substituted)
        correction = division.divide(numerator)
        updated.append(field.add(point[coordinate], field.negate(correction)))
    rows = [[[integer(coefficient) for coefficient in value[index:index + field.residue_degree]]
             for index in range(0, field.degree, field.residue_degree)] for value in updated]
    return {
        "field_def": dict(definition), "a_certified": rows,
    }, {
        "division_precision_lower_bound": division.remaining_precision,
        "coordinates_changed": updated != point,
    }


def certify_with_refinement(equations, branches, maximum_steps=4, separators=None):
    maximum_steps = integer(maximum_steps)
    if maximum_steps < 0:
        raise ValueError("Refinement limit must be nonnegative")
    current = list(branches)
    history = []
    result = certify_branches(equations, current, separators=separators)
    for step in range(1, maximum_steps + 1):
        if result["certified"] or not all(branch["hensel_certified"] for branch in result["branches"]):
            break
        proposed, diagnostics = [], []
        try:
            for branch in current:
                updated, diagnostic = refine_once(equations, branch)
                proposed.append(updated)
                diagnostics.append(diagnostic)
        except ValueError as error:
            history.append({"step": step, "candidate_refinement_error": str(error)})
            break
        history.append({"step": step, "branches": diagnostics})
        current = proposed
        result = certify_branches(equations, current, separators=separators)
        if not any(diagnostic["coordinates_changed"] for diagnostic in diagnostics):
            break
    result["refinement_history"] = history
    result["refinement_steps"] = sum("branches" in record for record in history)
    if history:
        result["refined_branches"] = current
    return result

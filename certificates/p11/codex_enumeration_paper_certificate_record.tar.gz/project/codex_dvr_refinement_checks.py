"""Verify integral Newton candidate updates and ensure they cannot bypass certification."""

import random
import unittest

from codex_dvr_branch_certificate import DVRField, certify_branches
from codex_dvr_branch_checks import branch
from codex_dvr_refinement import IntegralDivision, certify_with_refinement


class DVRRefinementChecks(unittest.TestCase):
    def test_integral_division_precision(self):
        generator = random.Random(260902)
        for ramification in (1, 2, 3):
            field = DVRField(13, 8, [0, 1], ramification, [2])
            denominator = field.uniformizer()
            division = IntegralDivision(field, denominator)
            for attempt in range(10):
                expected = field.element([generator.randrange(field.modulus) for index in range(field.degree)])
                numerator = field.multiply(denominator, expected)
                recovered = division.divide(numerator)
                error = field.add(recovered, field.negate(expected))
                self.assertGreaterEqual(field.coefficient_valuation(error), division.remaining_precision)

    def test_nonintegral_division_is_rejected(self):
        field = DVRField(13, 8, [0, 1], 2, [1])
        division = IntegralDivision(field, field.uniformizer())
        with self.assertRaises(ValueError):
            division.divide(field.one)

    def test_extra_accuracy_resolves_field_separation(self):
        equations = [{(4,): (1, 1), (2,): (-39, 1), (0,): (338, 1)}]
        candidates = [branch([[169, 1]], ramification=2), branch([[169, 1]], ramification=2, unit=(2,))]
        initial = certify_branches(equations, candidates)
        self.assertFalse(initial["certified"])
        self.assertTrue(all(item["hensel_certified"] for item in initial["branches"]))
        result = certify_with_refinement(equations, candidates)
        self.assertTrue(result["certified"])
        self.assertEqual(result["simple_points_certified"], 4)
        self.assertGreater(result["refinement_steps"], 0)
        replay = certify_branches(equations, result["refined_branches"])
        self.assertTrue(replay["certified"])

    def test_refinement_never_certifies_duplicate_orbits(self):
        equations = [{(2,): (1, 1), (0,): (-13, 1)}]
        result = certify_with_refinement(equations, [branch([[0, 1]], ramification=2),
                                                    branch([[0, -1]], ramification=2)])
        self.assertFalse(result["certified"])
        self.assertEqual(result["simple_points_certified"], 0)

    def test_refinement_does_not_start_without_hensel(self):
        result = certify_with_refinement([{(2,): (1, 1)}], [branch([[13**5]])])
        self.assertFalse(result["certified"])
        self.assertEqual(result["refinement_steps"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)

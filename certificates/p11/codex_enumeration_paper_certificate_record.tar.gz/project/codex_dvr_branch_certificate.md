# Independent verification of local branch degrees and separation

## The issue this checks

A strict multivariate Hensel inequality proves the existence of a simple
point **in** a field. It does not prove that the point **generates** that field,
or that a second certified field-valued approximation represents a different
point or conjugacy orbit. Those are additional counting requirements.

On September 2, 2026, the former separation predicate
`radius > valuation(t)` was reproduced on the following example using
Fable's then-current Newton routine. In

\[
K=\mathbb Q_{13}(\pi),\qquad \pi^2=13,
\]

take `G(x)=x-13` and approximate point `a=13+13*pi`. With `v(13)=2`,
the routine correctly reports residual valuation 3, Jacobian valuation 0,
and correction radius 3. Since `v(a)=2`, the former predicate passes, but
the exact root is rational and cannot count as two points. The translated
quantity has `v(a-13)=3`, so its leading term is not strictly preserved.
Fable has since strengthened its predicate and added certified-coordinate
exports. This note does not claim that any actual profile was nonsimple.

## Input and independent arithmetic

Each branch supplies `field_def = {ell, M, m, b, u}` and `a_certified`.
The field is defined by

\[
m(\zeta)=0,\qquad \pi^b=\ell u(\zeta).
\]

The verifier checks that `ell` is prime, `m` is monic and irreducible modulo
`ell`, and `u` is a unit. It uses the integral basis `zeta^j*pi^i`, not the
candidate finder's arithmetic. Eisenstein's criterion over the unramified
extension gives degree `b*deg(m)` and valuation

\[
v\!\left(\sum c_{ij}\pi^i\zeta^j\right)
=\min_{i,j}\{i+b\,v_\ell(c_{ij})\}.
\]

All supplied integer representatives are treated as exact lifts in these
explicit fields. Computation modulo `ell^M` gives justified valuation lower
bounds for those lifts. No series truncation or Newton update is trusted.

## Existence and simplicity

The full rational-coefficient equations and their derivatives are evaluated
anew. Write `s=v(det J(a))`, with the determinant required to be resolved,
and let `r` be the lower bound for the minimum residual valuation. Require

\[
r>2s.
\]

The inverse-Jacobian adjugate bound is `-s`; the Newton contraction therefore
gives an exact simple point `a*` with `a*-a` in `pi^(r-s) O_K^d`.
This is the ordinary strict DVR Hensel condition, not a norm-sum condition.

## Field degree and distinctness

Set

\[
c=\left\lfloor\frac{r-s}{b}\right\rfloor.
\]

Then `a*-a` belongs to `ell^c O_K^d`. For an integral linear form `h`,
let `f(T)` be the characteristic polynomial of multiplication by `h(a)`
on the integral basis. Its exact counterpart for `h(a*)` has coefficients
congruent modulo `ell^c`: matrix entries and characteristic coefficients
are integral polynomial expressions. Consequently:

1. If `v_ell(disc(f)) < c`, the exact characteristic polynomial is squarefree.
   Hence the point has `degree(K/Q_ell)` different embedding images, each
   simple. No assumption about the candidate's edge labels is needed.
2. For two branches, if `v_ell(res(f_i,f_j)) < min(c_i,c_j)`, their exact
   characteristic polynomials have no common root. Thus no point is counted
   by both branches, even if their field presentations are isomorphic.

All individual discriminants and all pairwise resultants must pass for
one common linear form before the field degrees are summed. The result is
a rigorously certified **lower bound** on the number of simple solutions.
Matching a separately proved local length would additionally establish
exhaustion; this verifier does not assume presentation counts are lengths.

The test is sufficient, not necessary. Failure can reflect insufficient
precision, a nonseparating chosen linear form, redundant field presentations,
or an inaccurate candidate. It is not evidence of a multiple exact point.

## Checks

```sh
PYTHONDONTWRITEBYTECODE=1 python3 codex_dvr_branch_checks.py
```

The tests cover the translated false positive, redundant conjugate orbits,
two different guesses converging to one root, actual ramified and unramified
extensions, mixed fields, a coordinate that fails to generate the field,
repeated roots, malformed field data, and independent quotient arithmetic.

## Optional bounded candidate refinement

`codex_dvr_refinement.py` supplies extra Newton updates when Hensel already
passes but the separation inequalities need more accuracy. It uses Cramer's
rule in the independently implemented integral algebra. Integral division
uses the regular representation, with a conservative loss bounded by the
valuation of the denominator norm. This norm is used only for arithmetic
precision, not as a per-embedding Hensel or separation valuation.

Every updated point is treated as a new exact integer lift and the full
certificate is run again from scratch. The final proof does not depend on
correctness of the candidate refinement. Refined coordinates are saved for
independent replay, and the dataset driver checks their residue point again
before adding counts from different special fibres.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 codex_dvr_refinement_checks.py
PYTHONDONTWRITEBYTECODE=1 python3 codex_verify_dvr_batches.py --p 8 \
  --refinement-steps 4 --output codex_dvr_p8_refined_results.json
```

"""Audit Fable's exported branch coordinates without trusting its root-count flags."""

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
import glob
import hashlib
import io
import json
import multiprocessing
from pathlib import Path
import sys
import time

from codex_dvr_branch_certificate import DVRField, certify_branches
from codex_dvr_refinement import certify_with_refinement
from codex_verify_corank_candidates import DataOnlyUnpickler


def read_data(path):
    raw = Path(path).read_bytes()
    data = json.loads(raw) if Path(path).suffix == ".json" else DataOnlyUnpickler(io.BytesIO(raw)).load()
    return data, hashlib.sha256(raw).hexdigest()


def exported_candidates(record):
    if "orbits" in record:
        if record.get("branches"):
            raise ValueError("Ambiguous export contains both branch and orbit candidates")
        if isinstance(record["orbits"], dict):
            return list(record["orbits"].values()), "exported_orbits"
        if isinstance(record["orbits"], list):
            return list(record["orbits"]), "exported_orbits"
        raise ValueError("Orbit export must be a list or map of candidate records")
    return ([candidate for candidate in record.get("branches", [])
             if candidate.get("ok") and candidate.get("separates")], "selected_branches")


def check_residue(candidate, residue, prime):
    definition = candidate["field_def"]
    if definition["ell"] != prime:
        raise ValueError("Branch and equation primes disagree")
    field = DVRField(prime, definition["M"], definition["m"], definition["b"], definition["u"])
    point = [field.element(value) for value in candidate["a_certified"]]
    if len(point) != len(residue):
        raise ValueError("Wrong coordinate count")
    for coordinate, expected in zip(point, residue):
        if coordinate[0] % prime != expected:
            raise ValueError("Branch has the wrong residue point")
        if any(value % prime for value in coordinate[1:field.residue_degree]):
            raise ValueError("Branch residue is not the claimed rational special point")


def audit_record(stage, record, source, index, refinement_steps):
    label = tuple(record["point"])
    selected, candidate_source = exported_candidates(record)
    row = {
        "source": source, "source_record": index, "point": list(label),
        "claimed_complete": bool(record.get("complete")),
        "claimed_presentation_count": record.get("npres"),
        "claimed_certified_degree": record.get("certified_degree"),
        "selected_candidates": len(selected), "candidate_source": candidate_source,
    }
    if not selected or any("field_def" not in candidate or "a_certified" not in candidate for candidate in selected):
        row["status"] = "insufficient_exported_data"
        return row
    for candidate in selected:
        check_residue(candidate, label, stage["ell"])
    check = (certify_with_refinement(stage["G"], selected, maximum_steps=refinement_steps)
             if refinement_steps else certify_branches(stage["G"], selected))
    for candidate in check.get("refined_branches", []):
        check_residue(candidate, label, stage["ell"])
    row.update(status="certified" if check["certified"] else "inconclusive", check=check)
    if check["certified"]:
        row["matches_claimed_presentation_count"] = check["simple_points_certified"] == record.get("npres")
    return row


_WORKER_STAGE = None
_WORKER_REFINEMENT = 0


def initialize_worker(stage, refinement_steps):
    global _WORKER_STAGE, _WORKER_REFINEMENT
    _WORKER_STAGE = stage
    _WORKER_REFINEMENT = refinement_steps


def audit_worker(task):
    record, source, index = task
    return audit_record(_WORKER_STAGE, record, source, index, _WORKER_REFINEMENT)


def run(stage_path, paths, limit=None, refinement_steps=0, workers=1):
    started = time.monotonic()
    if workers < 1 or limit is not None and limit < 0:
        raise ValueError("Workers must be positive and the record limit nonnegative")
    code_sources = ["codex_dvr_branch_certificate.py", "codex_dvr_refinement.py", "codex_finite_algebra_certificate.py",
                    "codex_verify_dvr_batches.py"]
    directory = Path(__file__).parent
    checker_hashes = {name: hashlib.sha256((directory / name).read_bytes()).hexdigest() for name in code_sources}
    stage, stage_hash = read_data(stage_path)
    expected_labels = {tuple(point) for point, corank, presentations in stage["singular"] if corank == 2}
    seen, results, sources, tasks = set(), [], [], []
    for path in paths:
        records, source_hash = read_data(path)
        if isinstance(records, dict):
            records = records["points"]
        if not isinstance(records, list):
            raise ValueError("A batch must contain a list of point records")
        sources.append({"path": str(path), "sha256": source_hash, "records": len(records)})
        for index, record in enumerate(records):
            if limit is not None and len(tasks) >= limit:
                break
            label = tuple(record["point"])
            if label not in expected_labels:
                raise ValueError("Unexpected special point in branch dataset")
            if label in seen:
                raise ValueError("Repeated special point would invalidate aggregate counting")
            seen.add(label)
            tasks.append((record, str(path), index))
        if limit is not None and len(tasks) >= limit:
            break

    def collect(iterator):
        for row in iterator:
            results.append(row)
            if len(results) % 25 == 0:
                print(json.dumps({"checked": len(results), "statuses": dict(Counter(item["status"] for item in results)),
                                  "elapsed_seconds": time.monotonic() - started}), flush=True)

    if workers == 1 or len(tasks) < 2:
        collect(audit_record(stage, record, source, index, refinement_steps) for record, source, index in tasks)
    else:
        with ProcessPoolExecutor(max_workers=min(workers, len(tasks)), mp_context=multiprocessing.get_context("spawn"),
                                 initializer=initialize_worker, initargs=(stage, refinement_steps)) as pool:
            collect(pool.map(audit_worker, tasks, chunksize=1))
    final_hashes = {name: hashlib.sha256((directory / name).read_bytes()).hexdigest() for name in code_sources}
    if checker_hashes != final_hashes:
        raise RuntimeError("Checker source changed during the audit; rerun with stable source files")
    return {
        "created_utc": datetime.now(timezone.utc).isoformat(), "elapsed_seconds": time.monotonic() - started,
        "p": stage["p"], "prime": stage["ell"], "stage_source": str(stage_path), "stage_sha256": stage_hash,
        "source_batches": sources,
        "checker_sha256": checker_hashes,
        "expected_corank_two_special_points": len(expected_labels), "checked_special_points": len(seen),
        "maximum_refinement_steps": refinement_steps,
        "worker_processes": min(workers, len(tasks)),
        "complete_special_point_coverage": seen == expected_labels,
        "statuses": dict(Counter(row["status"] for row in results)),
        "simple_points_certified_lower_bound": sum(row["check"]["simple_points_certified"]
                                                    for row in results if row["status"] == "certified"),
        "claimed_complete_but_not_independently_certified": sum(row["claimed_complete"] and row["status"] != "certified"
                                                                for row in results),
        "certificates_matching_claimed_presentation_counts": sum(row.get("matches_claimed_presentation_count", False)
                                                                 for row in results),
        "interpretation": "Independent exact-equation Hensel, field-generation and pairwise-disjointness certificates. Presentation counts are compared, not assumed to be local lengths. Inconclusive is not a multiple point.",
        "results": results,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--p", type=int, default=8)
    parser.add_argument("--stage", type=Path)
    inputs = parser.add_mutually_exclusive_group()
    inputs.add_argument("--batches")
    inputs.add_argument("--batch-manifest", help="JSON list of exact batch paths, or - for standard input")
    parser.add_argument("--limit", type=int)
    parser.add_argument("--refinement-steps", type=int, default=0)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    stage = arguments.stage or Path("/tmp/fable/coll/stage1_p%d.pkl" % arguments.p)
    if arguments.batch_manifest:
        manifest = (sys.stdin.read() if arguments.batch_manifest == "-"
                    else Path(arguments.batch_manifest).read_text())
        selected = json.loads(manifest)
        if not isinstance(selected, list) or any(not isinstance(path, str) for path in selected):
            parser.error("Batch manifest must be a JSON list of file paths")
        if len(selected) != len(set(selected)):
            parser.error("Batch manifest contains repeated paths")
        paths = [Path(path) for path in selected]
    else:
        pattern = arguments.batches or "/tmp/fable/coll/corank2_p%d_chunk*.pkl" % arguments.p
        paths = [Path(path) for path in sorted(glob.glob(pattern))]
    if not paths:
        parser.error("No completed branch-export batches found")
    if arguments.refinement_steps < 0:
        parser.error("Refinement steps must be nonnegative")
    if arguments.workers < 1 or arguments.limit is not None and arguments.limit < 0:
        parser.error("Workers must be positive and the record limit nonnegative")
    result = run(stage, paths, arguments.limit, arguments.refinement_steps, arguments.workers)
    arguments.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key not in ("results", "source_batches")}, indent=2))


if __name__ == "__main__":
    main()

"""Tests include field-degree and duplicate-branch false-positive regressions."""

import random
import unittest

import sympy as sp

from codex_dvr_branch_certificate import DVRField, certify_branches
from codex_finite_algebra_certificate import FiniteAlgebra


def branch(point, prime=13, precision=16, ramification=1, unramified=(0, 1), unit=(1,)):
    return {
        "field_def": {"ell": prime, "M": precision, "m": list(unramified), "b": ramification, "u": list(unit)},
        "a_certified": point,
    }


class DVRBranchChecks(unittest.TestCase):
    def test_multiplication_against_monic_quotient(self):
        generator = random.Random(20260902)
        for degree in (1, 2, 3, 5):
            field = DVRField(13, 8, [0, 1], degree, [2])
            quotient = FiniteAlgebra([-26] + [0] * (degree - 1) + [1], 13, 8)
            for iteration in range(20):
                left = tuple(generator.randrange(field.modulus) for index in range(degree))
                right = tuple(generator.randrange(field.modulus) for index in range(degree))
                self.assertEqual(field.multiply(left, right), quotient.multiply(left, right))

    def test_eisenstein_relation_and_norm_valuation(self):
        field = DVRField(3, 12, [1, 0, 1], 2, [1, 1])
        uniformizer = field.uniformizer()
        self.assertEqual(field.multiply(uniformizer, uniformizer), field.element([3, 3]))
        self.assertEqual(field.valuation(uniformizer), 1)
        self.assertEqual(field.norm_valuation(uniformizer), 2)
        self.assertEqual(field.norm_valuation(field.scalar(3)), 4)

    def test_ramified_field_degree_is_certified(self):
        result = certify_branches([{(2,): (1, 1), (0,): (-13, 1)}],
                                  [branch([[0, 1]], ramification=2)])
        self.assertTrue(result["certified"])
        self.assertEqual(result["simple_points_certified"], 2)

    def test_translated_leading_term_false_positive(self):
        result = certify_branches([{(1,): (1, 1), (0,): (-13, 1)}],
                                  [branch([[13, 13]], ramification=2)])
        diagnostic = result["branches"][0]
        self.assertTrue(diagnostic["hensel_certified"])
        self.assertEqual(diagnostic["correction_valuation_lower_bound"], 3)
        self.assertFalse(result["certified"])
        self.assertEqual(result["simple_points_certified"], 0)

    def test_exact_rational_point_does_not_generate_extension(self):
        result = certify_branches([{(1,): (1, 1), (0,): (-13, 1)}],
                                  [branch([[13, 0]], ramification=2)])
        self.assertTrue(result["branches"][0]["hensel_certified"])
        self.assertFalse(result["certified"])

    def test_distinct_ramified_and_rational_points(self):
        equations = [{(3,): (1, 1), (2,): (-13, 1), (1,): (-13, 1), (0,): (169, 1)}]
        result = certify_branches(equations, [branch([[13]]), branch([[0, 1]], ramification=2)])
        self.assertTrue(result["certified"])
        self.assertEqual(result["simple_points_certified"], 3)

    def test_two_guesses_lifting_to_one_point_are_not_counted_twice(self):
        equations = [{(2,): (1, 1), (1,): (-27, 1), (0,): (182, 1)}]
        result = certify_branches(equations, [branch([[13]]), branch([[13 + 13**8]])])
        self.assertTrue(all(item["hensel_certified"] for item in result["branches"]))
        self.assertFalse(result["certified"])
        self.assertTrue(any(check["kind"] == "resultant" and not check["passed"]
                            for check in result["separation_checks"]))

    def test_duplicate_conjugate_orbits_are_not_counted_twice(self):
        equations = [{(2,): (1, 1), (0,): (-13, 1)}]
        result = certify_branches(equations, [branch([[0, 1]], ramification=2),
                                              branch([[0, -1]], ramification=2)])
        self.assertFalse(result["certified"])
        self.assertTrue(all(item["hensel_certified"] for item in result["branches"]))

    def test_unramified_and_ramified_degree_four(self):
        equations = [{(4,): (1, 1), (2,): (-6, 1), (0,): (18, 1)}]
        result = certify_branches(equations, [branch([[[0, 0], [1, 0]]], prime=3,
                                                      ramification=2, unramified=(1, 0, 1), unit=(1, 1))])
        self.assertTrue(result["certified"])
        self.assertEqual(result["simple_points_certified"], 4)

    def test_separator_must_use_a_coordinate_generating_the_field(self):
        equations = [{(1, 0): (1, 1)}, {(0, 2): (1, 1), (0, 0): (-13, 1)}]
        result = certify_branches(equations, [branch([[0, 0], [0, 1]], ramification=2)])
        self.assertTrue(result["certified"])
        self.assertEqual(result["separator"], [0, 1])

    def test_repeated_root_fails_hensel(self):
        result = certify_branches([{(2,): (1, 1)}], [branch([[13**5]])])
        self.assertFalse(result["branches"][0]["hensel_certified"])
        self.assertFalse(result["certified"])

    def test_bad_field_data_is_rejected(self):
        for arguments in ((13, 8, [0, 0, 1], 2, [1]), (13, 8, [0, 1], 2, [13]),
                          (15, 8, [0, 1], 2, [1]), (13, 8, [0, 1], 0, [1])):
            with self.assertRaises(ValueError):
                DVRField(*arguments)


if __name__ == "__main__":
    unittest.main(verbosity=2)

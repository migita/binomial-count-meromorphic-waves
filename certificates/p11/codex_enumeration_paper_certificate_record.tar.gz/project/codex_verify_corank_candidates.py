"""Independently check untrusted finite-algebra starting data against exact equations."""

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import pickle
import time

from codex_finite_algebra_certificate import certify


class DataOnlyUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        raise pickle.UnpicklingError("Executable pickle globals are not allowed")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(candidates_path, equations_path, precision):
    started = time.monotonic()
    candidates_path = Path(candidates_path)
    equations_path = Path(equations_path)
    data = json.loads(candidates_path.read_text())
    with equations_path.open("rb") as handle:
        stage = DataOnlyUnpickler(handle).load()
    prime = int(data["ell"])
    if prime != stage["ell"] or int(data["p"]) != len(stage["G"]) + 1:
        raise ValueError("Candidate and equation metadata disagree")
    results = []
    labels = set()
    for index, candidate in enumerate(data["points"]):
        label = tuple(candidate["a0"])
        if label in labels:
            raise ValueError("Duplicate special-fibre labels would invalidate aggregate counting")
        labels.add(label)
        row = {"index": index, "a0": list(label), "claimed_presentations": candidate["npres"]}
        if "error" in candidate:
            row.update(status="no_candidate", candidate_error=candidate["error"])
        else:
            defining = candidate["D"]
            point = candidate["a_star"]
            if candidate["L"] != len(defining) - 1:
                raise ValueError("Candidate degree disagrees with its defining polynomial")
            if len(point) != len(label):
                raise ValueError("Candidate has the wrong coordinate count")
            if any(coefficient % prime for coefficient in defining[:-1]):
                raise ValueError("Candidate algebra does not have the claimed single residue")
            if any(not coordinate or coordinate[0] % prime != residue
                   for coordinate, residue in zip(point, label)):
                raise ValueError("Candidate coordinates do not have the claimed residue")
            check = certify(defining, prime, precision, point, stage["G"])
            row.update(status="certified" if check["certified"] else "inconclusive", check=check)
        results.append(row)
    statuses = Counter(row["status"] for row in results)
    reasons = Counter(row["check"]["reason"] for row in results if "check" in row)
    return {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": time.monotonic() - started,
        "p": data["p"], "prime": prime, "verification_precision": precision,
        "candidate_precision": data["K_series"], "candidate_series_order": data["E_series"],
        "candidate_source": str(candidates_path), "candidate_sha256": digest(candidates_path),
        "equation_source": str(equations_path), "equation_sha256": digest(equations_path),
        "checker_sha256": digest(Path(__file__).with_name("codex_finite_algebra_certificate.py")),
        "interpretation": "Inconclusive means no certificate, not a multiple point. Supplied presentation counts are not used as lengths.",
        "statuses": dict(statuses), "certificate_reasons": dict(reasons),
        "verified_simple_points_lower_bound": sum(
            row["check"]["simple_root_embeddings"] for row in results if row["status"] == "certified"
        ),
        "results": results,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidates", type=Path)
    parser.add_argument("equations", type=Path)
    parser.add_argument("--precision", type=int, default=16)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    result = run(arguments.candidates, arguments.equations, arguments.precision)
    arguments.output.write_text(json.dumps(result, indent=2) + "\n")
    summary = {key: value for key, value in result.items() if key != "results"}
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

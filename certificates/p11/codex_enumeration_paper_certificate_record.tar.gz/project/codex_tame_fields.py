"""Tame local-field extensions with explicit integral-basis embeddings, modulo known precision."""

from dataclasses import dataclass
from functools import lru_cache
import math

from flint import fmpz_mod_poly_ctx, fq_default_ctx, fq_default_poly_ctx
import sympy as sp

from codex_dvr_branch_certificate import DVRField
from codex_finite_algebra_certificate import FiniteAlgebra, integer


@lru_cache(maxsize=256)
def residue_context(prime, defining):
    polynomial = fmpz_mod_poly_ctx(prime)(list(defining))
    return fq_default_ctx(modulus=polynomial)


def residue_coefficients(value):
    return tuple(int(coefficient) for coefficient in value.to_list())


def polynomial_value(ring, coefficients, value):
    result = ring.zero
    for coefficient in reversed(coefficients):
        result = ring.add(ring.multiply(result, value), coefficient)
    return result


def unit_inverse(ring, value):
    context = residue_context(ring.prime, ring.defining)
    inverse_residue = context([coefficient % ring.prime for coefficient in value]).inverse()
    result = ring.element(residue_coefficients(inverse_residue))
    for iteration in range(ring.precision.bit_length() + 1):
        error = ring.add(ring.scalar(2), ring.negate(ring.multiply(value, result)))
        result = ring.multiply(result, error)
    if ring.multiply(value, result) != ring.one:
        raise ArithmeticError("Unramified unit inverse did not reach the requested precision")
    return result


def ring_power(ring, value, exponent):
    exponent = integer(exponent)
    if exponent < 0:
        value = unit_inverse(ring, value)
        exponent = -exponent
    result = ring.one
    while exponent:
        if exponent & 1:
            result = ring.multiply(result, value)
        value = ring.multiply(value, value)
        exponent //= 2
    return result


def hensel_unramified_root(ring, coefficients, residue):
    value = ring.element(residue)
    derivative = [ring.scale(index, coefficient) for index, coefficient in enumerate(coefficients)][1:]
    for iteration in range(ring.precision.bit_length() + 1):
        residual = polynomial_value(ring, coefficients, value)
        if residual == ring.zero:
            return value
        derivative_value = polynomial_value(ring, derivative, value)
        correction = ring.multiply(residual, unit_inverse(ring, derivative_value))
        value = ring.add(value, ring.negate(correction))
    if polynomial_value(ring, coefficients, value) != ring.zero:
        raise ArithmeticError("Unramified root lift did not reach the requested precision")
    return value


def field_definition(field):
    return {"ell": field.prime, "M": field.precision, "m": list(field.unramified.defining),
            "b": field.ramification, "u": list(field.unit)}


def from_lfield(field):
    if field.a != 1:
        raise ValueError("The source must use an Eisenstein uniformizer")
    return DVRField(field.ell, field.M, field.m, field.b, field.u)


class FieldEmbedding:
    """A checked homomorphism of integral-basis arithmetic modulo prime^precision."""

    def __init__(self, source, target, zeta_image, uniformizer_image):
        if source.prime != target.prime or source.precision < target.precision:
            raise ValueError("Embedding requires one prime and sufficient source precision")
        self.source, self.target = source, target
        self.zeta_image = target.element(zeta_image)
        self.uniformizer_image = target.element(uniformizer_image)
        zeta_powers = [ring_power(target, self.zeta_image, exponent) for exponent in range(source.residue_degree)]
        pi_powers = [ring_power(target, self.uniformizer_image, exponent) for exponent in range(source.ramification)]
        self.basis_images = [target.multiply(pi_power, zeta_power) for pi_power in pi_powers for zeta_power in zeta_powers]
        base_polynomial = [target.scalar(coefficient) for coefficient in source.unramified.defining]
        if polynomial_value(target, base_polynomial, self.zeta_image) != target.zero:
            raise ArithmeticError("Unramified generator image does not satisfy the source relation")
        image_unit = self.apply(source.element(source.unit))
        if ring_power(target, self.uniformizer_image, source.ramification) != target.scale(source.prime, image_unit):
            raise ArithmeticError("Uniformizer image does not satisfy the source relation")

    def apply(self, value):
        value = self.source.element(value)
        result = self.target.zero
        for coefficient, image in zip(value, self.basis_images):
            if coefficient:
                result = self.target.add(result, self.target.scale(coefficient, image))
        return result

    def then(self, following):
        if field_definition(self.target) != field_definition(following.source):
            raise ValueError("Embedding targets and sources disagree")
        return FieldEmbedding(self.source, following.target,
                              following.apply(self.zeta_image), following.apply(self.uniformizer_image))


@dataclass
class TameExtension:
    field: DVRField
    embedding: FieldEmbedding
    leading_root: tuple
    relative_ramification: int
    relative_residue_degree: int
    slope_numerator: int
    slope_denominator: int

    @property
    def relative_degree(self):
        return self.relative_ramification * self.relative_residue_degree


def tame_extension(base, numerator, denominator, irreducible_factor):
    """Realize x^denominator = pi_base^numerator * theta in one Eisenstein presentation."""
    numerator, denominator = integer(numerator), integer(denominator)
    if numerator <= 0 or denominator <= 0 or math.gcd(numerator, denominator) != 1:
        raise ValueError("A positive slope in lowest terms is required")
    if base.ramification % base.prime == 0 or denominator % base.prime == 0:
        raise ValueError("This extension helper is restricted to tame ramification")
    old_residue = residue_context(base.prime, base.unramified.defining)
    old_polynomials = fq_default_poly_ctx(old_residue)
    factor_coefficients = [old_residue(list(value)) for value in irreducible_factor]
    factor = old_polynomials(factor_coefficients)
    if factor.degree() < 1 or not factor.is_monic() or not factor.is_irreducible() or factor[0].is_zero():
        raise ValueError("A monic irreducible edge factor with nonzero constant term is required")
    relative_residue = factor.degree()
    if relative_residue == 1:
        target_residue = old_residue
        old_generator_residue = target_residue.gen()
    else:
        target_residue = fq_default_ctx(base.prime, base.residue_degree * relative_residue)
        polynomial_context = fq_default_poly_ctx(target_residue)
        old_relation = polynomial_context([target_residue(coefficient) for coefficient in base.unramified.defining])
        roots = old_relation.roots(multiplicities=False)
        if len(roots) != base.residue_degree:
            raise ArithmeticError("The residue extension does not contain the source field")
        old_generator_residue = min(roots, key=residue_coefficients)
    modulus = [int(coefficient) for coefficient in target_residue.modulus()]
    unramified = FiniteAlgebra(modulus, base.prime, base.precision)
    old_coefficients = [unramified.scalar(coefficient) for coefficient in base.unramified.defining]
    old_generator = hensel_unramified_root(unramified, old_coefficients, residue_coefficients(old_generator_residue))

    def map_unramified(value):
        return polynomial_value(unramified, [unramified.scalar(coefficient) for coefficient in value], old_generator)

    mapped_factor = [map_unramified(residue_coefficients(coefficient)) for coefficient in factor_coefficients]
    target_polynomials = fq_default_poly_ctx(target_residue)
    residue_factor = target_polynomials([target_residue([coefficient % base.prime for coefficient in value])
                                         for value in mapped_factor])
    residue_roots = residue_factor.roots(multiplicities=False)
    if len(residue_roots) != relative_residue:
        raise ArithmeticError("The edge factor does not split in the constructed residue extension")
    theta_residue = min(residue_roots, key=residue_coefficients)
    theta = unramified.element(residue_coefficients(theta_residue))
    bezout_first, bezout_second, gcd = map(integer, sp.gcdex(numerator, denominator))
    if gcd != 1:
        raise ArithmeticError("Unexpected noncoprime slope")
    mapped_unit = map_unramified(base.unit)
    new_unit = unramified.multiply(mapped_unit, ring_power(unramified, theta, bezout_first * base.ramification))
    target = DVRField(base.prime, base.precision, modulus, base.ramification * denominator, new_unit)
    omega = target.uniformizer()
    theta_value = target.element(theta)
    base_pi_image = target.multiply(ring_power(target, omega, denominator),
                                    target.element(ring_power(unramified, theta, -bezout_first)))
    seed = target.multiply(ring_power(target, omega, numerator),
                           target.element(ring_power(unramified, theta, bezout_second)))
    embedding = FieldEmbedding(base, target, target.element(old_generator), base_pi_image)
    expected_power = target.multiply(ring_power(target, base_pi_image, numerator), theta_value)
    if ring_power(target, seed, denominator) != expected_power:
        raise ArithmeticError("The leading root does not satisfy the binomial relation")
    return TameExtension(target, embedding, seed, denominator, relative_residue, numerator, denominator)

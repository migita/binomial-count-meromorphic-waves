"""Conservative simple-root certificates using strict coefficient-norm Hensel bounds."""

from fractions import Fraction
import operator

import sympy as sp


def integer(value):
    return operator.index(value)


class FiniteAlgebra:
    def __init__(self, defining, prime, precision):
        self.prime = integer(prime)
        self.precision = integer(precision)
        self.defining = tuple(integer(value) for value in defining)
        if not sp.isprime(self.prime) or self.precision < 1:
            raise ValueError("A prime and positive integer precision are required")
        if len(self.defining) < 2 or self.defining[-1] != 1:
            raise ValueError("The defining polynomial must be monic and nonconstant")
        self.degree = len(self.defining) - 1
        self.modulus = self.prime**self.precision
        self.zero = (0,) * self.degree
        self.one = (1,) + (0,) * (self.degree - 1)

    def element(self, coefficients):
        coefficients = [integer(value) % self.modulus for value in coefficients]
        for power in range(len(coefficients) - 1, self.degree - 1, -1):
            leading = coefficients[power]
            if leading:
                for index, coefficient in enumerate(self.defining[:-1]):
                    position = power - self.degree + index
                    coefficients[position] = (coefficients[position] - leading * coefficient) % self.modulus
        return tuple((coefficients + [0] * self.degree)[:self.degree])

    def scalar(self, value):
        return (integer(value) % self.modulus,) + (0,) * (self.degree - 1)

    def add(self, left, right):
        return tuple((first + second) % self.modulus for first, second in zip(left, right))

    def negate(self, value):
        return tuple(-coefficient % self.modulus for coefficient in value)

    def scale(self, coefficient, value):
        return tuple(coefficient * entry % self.modulus for entry in value)

    def multiply(self, left, right):
        if left == self.zero or right == self.zero:
            return self.zero
        coefficients = [0] * (2 * self.degree - 1)
        for first_index, first in enumerate(left):
            if first:
                for second_index, second in enumerate(right):
                    if second:
                        coefficients[first_index + second_index] += first * second
        return self.element(coefficients)

    def integer_valuation(self, value):
        value %= self.modulus
        if not value:
            return self.precision
        valuation = 0
        while value % self.prime == 0:
            value //= self.prime
            valuation += 1
        return valuation

    def coefficient_valuation(self, value):
        return min(self.integer_valuation(coefficient) for coefficient in value)

    def multiplication_matrix(self, value):
        columns = []
        for index in range(self.degree):
            basis = (0,) * index + (1,) + (0,) * (self.degree - index - 1)
            columns.append(self.multiply(value, basis))
        return sp.Matrix(self.degree, self.degree, lambda row, column: columns[column][row])

    def norm_valuation(self, value):
        determinant = integer(self.multiplication_matrix(value).det(method="domain-ge"))
        return self.integer_valuation(determinant)

    def characteristic(self, matrix):
        size = len(matrix)
        if not size:
            return [self.one]
        submatrix = [row[1:] for row in matrix[1:]]
        smaller = self.characteristic(submatrix)
        column = [row[0] for row in matrix[1:]]
        first_row = matrix[0][1:]
        sequence = [self.one, self.negate(matrix[0][0])]
        for power in range(size - 1):
            product = self.zero
            for left, right in zip(first_row, column):
                product = self.add(product, self.multiply(left, right))
            sequence.append(self.negate(product))
            if power + 1 < size - 1:
                next_column = []
                for row in submatrix:
                    value = self.zero
                    for left, right in zip(row, column):
                        value = self.add(value, self.multiply(left, right))
                    next_column.append(value)
                column = next_column
        result = []
        for degree in range(size + 1):
            coefficient = self.zero
            for index in range(min(degree + 1, len(smaller))):
                coefficient = self.add(
                    coefficient, self.multiply(sequence[degree - index], smaller[index])
                )
            result.append(coefficient)
        return result

    def determinant(self, matrix):
        value = self.characteristic(matrix)[-1]
        return self.negate(value) if len(matrix) % 2 else value

    def separating_discriminant_valuation(self, value):
        coordinate = sp.Symbol("coordinate")
        characteristic = self.multiplication_matrix(value).charpoly(coordinate)
        coefficients = [integer(coefficient) % self.modulus for coefficient in characteristic.all_coeffs()]
        polynomial = sp.Poly.from_list(coefficients, coordinate, domain=sp.ZZ)
        return self.integer_valuation(integer(polynomial.discriminant()))


def normalize_equations(equations, dimension, prime):
    if len(equations) != dimension:
        raise ValueError("The certificate requires a square polynomial system")
    normalized = []
    for polynomial in equations:
        terms = {}
        for powers, rational in polynomial.items():
            powers = tuple(integer(power) for power in powers)
            if len(powers) != dimension or any(power < 0 for power in powers):
                raise ValueError("Invalid monomial")
            coefficient = Fraction(integer(rational[0]), integer(rational[1]))
            if coefficient.denominator % prime == 0:
                raise ValueError("Equation coefficients must be integral at the chosen prime")
            if coefficient:
                terms[powers] = coefficient
        normalized.append(terms)
    return normalized


def evaluate_system(algebra, equations, point):
    dimension = len(point)
    maximums = [0] * dimension
    for polynomial in equations:
        for monomial in polynomial:
            for index, power in enumerate(monomial):
                maximums[index] = max(maximums[index], power)
    powers = []
    for value, maximum in zip(point, maximums):
        coordinate_powers = [algebra.one]
        for power in range(maximum):
            coordinate_powers.append(algebra.multiply(coordinate_powers[-1], value))
        powers.append(coordinate_powers)
    residuals, jacobian = [], []
    for polynomial in equations:
        residual = algebra.zero
        derivatives = [algebra.zero] * dimension
        for monomial, coefficient in polynomial.items():
            scalar = coefficient.numerator * pow(coefficient.denominator, -1, algebra.modulus) % algebra.modulus
            value = algebra.scalar(scalar)
            for index, power in enumerate(monomial):
                if power:
                    value = algebra.multiply(value, powers[index][power])
            residual = algebra.add(residual, value)
            for variable, exponent in enumerate(monomial):
                if not exponent:
                    continue
                derivative = algebra.scalar(scalar * exponent)
                for index, power in enumerate(monomial):
                    adjusted = power - int(index == variable)
                    if adjusted:
                        derivative = algebra.multiply(derivative, powers[index][adjusted])
                derivatives[variable] = algebra.add(derivatives[variable], derivative)
        residuals.append(residual)
        jacobian.append(derivatives)
    return residuals, jacobian


def certify(defining, prime, precision, point, equations, separators=None):
    """Check exact integer lifts, with rational-coefficient equations; perform no Newton division."""
    algebra = FiniteAlgebra(defining, prime, precision)
    if not point:
        raise ValueError("A nonempty point is required")
    point = [algebra.element(coordinates) for coordinates in point]
    dimension = len(point)
    equations = normalize_equations(equations, dimension, algebra.prime)
    residuals, jacobian = evaluate_system(algebra, equations, point)
    determinant = algebra.determinant(jacobian)
    norm_valuation = algebra.norm_valuation(determinant)
    residual_valuation = min(algebra.coefficient_valuation(value) for value in residuals)
    result = {
        "certified": False, "hensel_certified": False, "L": algebra.degree,
        "precision": algebra.precision,
        "residual_valuation_lower_bound": residual_valuation,
        "norm_jacobian_valuation": norm_valuation if norm_valuation < algebra.precision else None,
        "simple_root_embeddings": 0,
    }
    if norm_valuation >= algebra.precision:
        result["reason"] = "jacobian_norm_not_resolved_at_this_precision"
        return result
    if residual_valuation <= 2 * norm_valuation:
        result["reason"] = "strict_coefficient_norm_hensel_bound_not_met"
        return result
    error_precision = residual_valuation - norm_valuation
    result.update(hensel_certified=True, correction_valuation_lower_bound=error_precision)
    if all(coefficient % algebra.prime == 0 for coefficient in algebra.defining[:-1]):
        result["common_residue"] = [value[0] % algebra.prime for value in point]
    if separators is None:
        separators = [tuple(int(index == variable) for index in range(dimension))
                      for variable in range(dimension)]
        separators += [tuple(base**index for index in range(dimension)) for base in (2, 3, 5)]
    tested = set()
    best_discriminant = algebra.precision
    for weights in separators:
        weights = tuple(integer(weight) for weight in weights)
        if len(weights) != dimension:
            raise ValueError("Separator weights have the wrong dimension")
        if weights in tested:
            continue
        tested.add(weights)
        value = algebra.zero
        for weight, coordinate in zip(weights, point):
            value = algebra.add(value, algebra.scale(weight, coordinate))
        discriminant_valuation = algebra.separating_discriminant_valuation(value)
        best_discriminant = min(best_discriminant, discriminant_valuation)
        if discriminant_valuation < error_precision:
            result.update(
                certified=True, simple_root_embeddings=algebra.degree,
                separator=list(weights), separation_discriminant_valuation=discriminant_valuation,
                reason="strict_hensel_and_stable_separating_discriminant",
            )
            return result
    result.update(reason="no_tested_separator_certified",
                  separation_discriminant_valuation_lower_bound=best_discriminant)
    return result

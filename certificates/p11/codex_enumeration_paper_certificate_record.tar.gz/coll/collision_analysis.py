"""Structured reducedness certificate for X_p at a gap-2 prime l = 2p-3 (Codex's plan, implemented by Fable).
Stage 1: exact equations G_r = l*F_r (l-integral), special fibre enumeration via presentations A = B*C (B | x^l - x, C | S_A),
         dedupe, Jacobian rank mod l at every special point (over F_l, or F_{l^2} for the quadratic-extension points).
Stage 2 (local_analysis.py): l-adic Weierstrass/Hensel analysis at the singular special points."""
import sympy as sp, itertools, math, json, sys, time, pickle
import numpy as np
sys.path.insert(0, '/tmp/fable')
from audit_congruence import H_discrete, x

def exact_equations(p, ell):
    """F_r (rational) = coefficients of rem_A(H_A); returns a, G_r = ell*F_r as dicts {exponent tuple: Fraction-> int mod nothing},
    verified ell-integral, plus the reduction mod ell."""
    d = p - 1; a = sp.symbols('a1:%d' % (d + 1))
    A = x**d + sum(a[i] * x**(d - 1 - i) for i in range(d))
    coeffs = [sp.Poly(A, x).coeff_monomial(x**k) for k in range(d + 1)]
    H = H_discrete(coeffs)                                     # exact rational polynomial in x, quadratic in a
    q, r = sp.div(H.as_expr(), A, x)
    G = []
    for k in range(d):
        Fk = sp.Poly(sp.expand(sp.Poly(r, x).coeff_monomial(x**k)), *a)
        terms = {}
        for mono, c in Fk.terms():
            c = sp.Rational(c) * ell
            num, den = int(c.p), int(c.q)
            assert den % ell != 0, 'not ell-integral after scaling by ell: r=%d mono=%s c=%s' % (k, mono, c)
            terms[mono] = (num, den)                           # keep exact rational (den coprime to ell)
        G.append(terms)
    return a, G, q

def reduce_terms(terms, modulus):
    out = {}
    for mono, (num, den) in terms.items():
        v = (num * pow(den, -1, modulus)) % modulus
        if v: out[mono] = v
    return out

def poly_eval_batch(terms_mod, pts, modulus):
    """Evaluate a polynomial (dict mono->coeff mod modulus) at many points; pts: int64 array (npts, nvars) with entries in [0,modulus)."""
    npts, nvars = pts.shape
    maxdeg = max((max(m) for m in terms_mod), default=0)
    powers = [np.ones((npts,), dtype=np.int64)]
    # powers[k][:, j] = pts[:, j]^k mod modulus
    P = np.ones((maxdeg + 1, npts, nvars), dtype=np.int64)
    for k in range(1, maxdeg + 1):
        P[k] = (P[k - 1] * pts) % modulus
    acc = np.zeros(npts, dtype=np.int64)
    for mono, c in terms_mod.items():
        t = np.full(npts, c, dtype=np.int64)
        for j, e in enumerate(mono):
            if e: t = (t * P[e, :, j]) % modulus
        acc = (acc + t) % modulus
    return acc

def derivative_terms(terms_mod, j, modulus):
    out = {}
    for mono, c in terms_mod.items():
        e = mono[j]
        if e == 0: continue
        m2 = list(mono); m2[j] -= 1
        v = (c * e) % modulus
        if v: out[tuple(m2)] = (out.get(tuple(m2), 0) + v) % modulus
    return out

def poly_from_roots(roots, modulus):
    c = [1]
    for r in roots:
        c = [( (c[i] if i < len(c) else 0) - r * (c[i - 1] if i >= 1 else 0)) % modulus for i in range(len(c) + 1)]
    return c   # c[i] = coefficient of x^i ... careful: build as list of coefficients low->high

def polymul(u, v, modulus):
    out = [0] * (len(u) + len(v) - 1)
    for i, ui in enumerate(u):
        if ui == 0: continue
        for j, vj in enumerate(v):
            out[i + j] = (out[i + j] + ui * vj) % modulus
    return out

def enumerate_special_fibre(p, ell):
    """Presentations A = B*C over F_ell (deg C = 0,1,2), returning coefficient vectors a (a_1..a_d as ints mod ell) for the
    F_ell-rational points and a separate list for F_{ell^2} points (deg C = 1 with root outside F_ell)."""
    d = p - 1; assert 2 * p - 1 == ell + 2
    inv = lambda z: pow(z, -1, ell)
    def coeffs_of_B(T):     # monic polynomial with roots T (list of residues); returns coefficient list high->low: [1, b1, b2, ...]
        c = [1]
        for r in T:
            c = [1] + [ (c[i] - r * c[i - 1]) % ell for i in range(1, len(c)) ] + [(-r * c[-1]) % ell]
        return c
    pres = []           # (a_vector tuple, type, info)
    nonsq = {z for z in range(1, ell) if pow(z, (ell - 1) // 2, ell) == ell - 1}
    # deg C = 0
    for T in itertools.combinations(range(ell), d):
        c = coeffs_of_B(T)
        pres.append((tuple(c[1:]), 'B', T))
    # deg C = 1: C = x + cc, root of cc^2 - 8 b1 cc + 8 b1^2 - 16 b2 = 0
    ext = []            # F_{ell^2} points: (B coefficients, b1, b2, disc) with two conjugate roots
    for T in itertools.combinations(range(ell), d - 1):
        c = coeffs_of_B(T); b1, b2 = c[1], c[2]
        disc = (64 * b1 * b1 - 4 * (8 * b1 * b1 - 16 * b2)) % ell          # = 32(b1^2 + 2 b2)
        if disc == 0:
            cc = (8 * b1 * inv(2)) % ell
            A = polymul([1] + list(c[1:]), [1, cc], ell)
            pres.append((tuple(A[1:]), 'BC1double', (T, cc)))
            pres.append((tuple(A[1:]), 'BC1double', (T, cc)))               # two presentations (double root of the quadratic)
        elif disc in nonsq:
            ext.append((tuple(c[1:]), b1, b2, disc, T))
        else:
            s = next(z for z in range(ell) if (z * z) % ell == disc)
            for cc in [((8 * b1 + s) * inv(2)) % ell, ((8 * b1 - s) * inv(2)) % ell]:
                A = polymul([1] + list(c[1:]), [1, cc], ell)
                pres.append((tuple(A[1:]), 'BC1', (T, cc)))
    # deg C = 2: C = S_A: 7 c1 = -8 b1 ; 17 c2 = 8 b1^2 + 8 c1^2 - 16 b2
    for T in itertools.combinations(range(ell), d - 2):
        c = coeffs_of_B(T); b1, b2 = c[1], c[2]
        c1 = (-8 * b1 * inv(7)) % ell
        c2 = ((8 * b1 * b1 + 8 * c1 * c1 - 16 * b2) * inv(17)) % ell
        A = polymul([1] + list(c[1:]), [1, c1, c2], ell)
        pres.append((tuple(A[1:]), 'BC2', (T, c1, c2)))
    return pres, ext

if __name__ == '__main__':
    p = int(sys.argv[1]); ell = 2 * p - 3; d = p - 1
    assert sp.isprime(ell) and ell not in (7, 17)
    t0 = time.time()
    a, G, q = exact_equations(p, ell)
    print('equations built: %d, terms %s, %.0fs' % (len(G), [len(g) for g in G], time.time() - t0), flush=True)
    Gmod = [reduce_terms(g, ell) for g in G]
    # sanity: reduced equations should equal coefficients of rem_A(u (x^ell - x) S_A) mod ell  (u = ell (d!)^2 / (2d+1)! mod ell)
    pres, ext = enumerate_special_fibre(p, ell)
    print('presentations (F_ell-rational): %d, F_{ell^2} pairs: %d, total = %d, expected %d' % (len(pres), len(ext), len(pres) + 2 * len(ext), math.comb(2 * p - 1, p - 1)), flush=True)
    pts = {}
    for avec, typ, info in pres:
        pts.setdefault(avec, []).append((typ, info))
    print('distinct F_ell-rational special points: %d (of which with >1 presentation: %d)' % (len(pts), sum(1 for v in pts.values() if len(v) > 1)), flush=True)
    # residual check: every point must satisfy the reduced equations
    keys = list(pts.keys()); P = np.array(keys, dtype=np.int64)
    for r, g in enumerate(Gmod):
        vals = poly_eval_batch(g, P, ell)
        bad = int(np.count_nonzero(vals))
        print('  reduced equation %d vanishes at all special points: %s' % (r, bad == 0), flush=True)
        assert bad == 0
    # Jacobian rank mod ell at each F_ell point
    t1 = time.time()
    J = np.zeros((len(keys), d, d), dtype=np.int64)
    for r, g in enumerate(Gmod):
        for j in range(d):
            J[:, r, j] = poly_eval_batch(derivative_terms(g, j, ell), P, ell)
    print('jacobians evaluated, %.0fs' % (time.time() - t1), flush=True)
    def rank_mod(M, modulus):
        M = M.copy() % modulus; n, m = M.shape; rk = 0; row = 0
        for col in range(m):
            piv = None
            for i in range(row, n):
                if M[i, col] % modulus: piv = i; break
            if piv is None: continue
            M[[row, piv]] = M[[piv, row]]
            invp = pow(int(M[row, col]), -1, modulus)
            M[row] = (M[row] * invp) % modulus
            for i in range(n):
                if i != row and M[i, col]: M[i] = (M[i] - M[i, col] * M[row]) % modulus
            row += 1; rk += 1
            if row == n: break
        return rk
    coranks = {}
    singular = []
    for i, k in enumerate(keys):
        rk = rank_mod(J[i], ell); cr = d - rk
        coranks[cr] = coranks.get(cr, 0) + 1
        if cr > 0: singular.append((k, cr, pts[k]))
    print('corank distribution over F_ell points:', coranks, '%.0fs' % (time.time() - t1), flush=True)
    npres_at_singular = sum(len(pts[k]) for k, cr, _ in singular)
    print('presentations sitting at singular points: %d ; simple F_ell points: %d ; F_{ell^2} points (expected simple): %d' % (npres_at_singular, coranks.get(0, 0), 2 * len(ext)), flush=True)
    print('length accounting: simple F_ell + F_ell^2 + presentations at singular = %d (expected %d)' % (coranks.get(0, 0) + 2 * len(ext) + npres_at_singular, math.comb(2 * p - 1, p - 1)))
    pickle.dump({'p': p, 'ell': ell, 'a': [str(v) for v in a], 'G': G, 'singular': singular, 'ext': ext, 'coranks': coranks, 'n_simple_rational': coranks.get(0, 0)}, open('/tmp/fable/coll/stage1_p%d.pkl' % p, 'wb'))
    print('saved stage1_p%d.pkl, total %.0fs' % (p, time.time() - t0))

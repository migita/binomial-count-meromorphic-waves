"""Run corank2_v2 on the p=11 corank-2 points left incomplete by the first-generation batch, in parallel chunks."""
import pickle, glob, sys, time
sys.path.insert(0, '/tmp/fable/coll')
import corank2_v2 as v2
chunk, nchunks, listfile, tag = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3], sys.argv[4]
import json
inc = json.load(open(listfile))
inc = inc[chunk::nchunks]
st = pickle.load(open('/tmp/fable/coll/stage1_p11.pkl', 'rb'))
npres = {tuple(int(v) for v in a0): len(pr) for a0, cr, pr in st['singular'] if cr == 2}
results = []; t0 = time.time()
for idx, a0 in enumerate(inc):
    try: out = v2.certify_point_v2(st, a0, npres[tuple(a0)])
    except Exception as e: out = {'error': repr(e), 'complete': False, 'npres': npres[tuple(a0)], 'certified_degree': 0}
    out['point'] = list(a0); results.append(out)
    if (idx + 1) % 5 == 0: print('  %d/%d, %.0fs, complete %d, over %d' % (idx + 1, len(inc), time.time() - t0, sum(1 for r in results if r.get('complete')), sum(1 for r in results if r.get('over'))), flush=True)
pickle.dump(results, open('/tmp/fable/coll/corank2v2_p11_%s_chunk%03d.pkl' % (tag, chunk), 'wb'))
print('V2 chunk %d done: %d points, complete %d, over %d, %.0fs' % (chunk, len(results), sum(1 for r in results if r.get('complete')), sum(1 for r in results if r.get('over')), time.time() - t0), flush=True)

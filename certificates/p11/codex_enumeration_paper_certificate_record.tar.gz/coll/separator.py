"""Tail-aware l-adic separation of the small roots of a germ g in Z_l[[eps]] known modulo (l^K, eps^E)  (E=None: no eps-truncation,
the polynomial is an exact representative modulo l^K).  Follows the error control required in codex_false_positive_notice.md:
after the refinement eps = l^s (theta + tau), division by l^v0, the germ is known modulo l^{min(K - v0, s*E - v0)} with no further
eps-truncation.  A first-level edge of slope s is trusted only if s*E > v0, so the omitted tail cannot reach its edge polynomial.
Returns dict(L, distinct, flags); a certificate requires distinct == L and no flags."""
import math, sympy as sp
from fractions import Fraction

def val(v, ell, cap):
    v = int(v)
    if v == 0: return cap
    k = 0
    while v % ell == 0 and k < cap: v //= ell; k += 1
    return k

def poly_mod_ell(coeffs, ell):
    T = sp.Symbol('T'); return sp.Poly(sum(int(c) * T**k for k, c in enumerate(coeffs)), T, modulus=ell), T

def separate(g, ell, K, E, depth=0):
    mod = ell**K
    g = [int(v) % mod for v in g]
    if E is not None: g = g[:E] + [0] * max(0, E - len(g))
    vals = [val(c, ell, K) for c in g]
    L = next((k for k, v in enumerate(vals) if v == 0), None)
    if L is None: return {'L': None, 'distinct': 0, 'flags': ['no unit coefficient within the known jet (precision/truncation)']}
    if L == 0: return {'L': 0, 'distinct': 0, 'flags': []}
    if E is not None and L >= E: return {'L': L, 'distinct': 0, 'flags': ['local length %d not below truncation order %d' % (L, E)]}
    pts = [(i, vals[i]) for i in range(L + 1)]                   # unknown valuations enter as K (a lower bound)
    hull = [pts[0]]
    for pt in pts[1:]:
        while len(hull) >= 2:
            (x1, y1), (x2, y2) = hull[-2], hull[-1]; x3, y3 = pt
            if (y2 - y1) * (x3 - x1) >= (y3 - y1) * (x2 - x1): hull.pop()
            else: break
        hull.append(pt)
    edges = list(zip(hull, hull[1:]))
    slopes = [Fraction(v0 - v1, i1 - i0) for (i0, v0), (i1, v1) in edges]
    distinct = 0; flags = []
    for e_idx, (((i0, v0), (i1, v1)), s) in enumerate(zip(edges, slopes)):
        n_e = i1 - i0
        if v0 >= K:
            # left vertex only known to have valuation >= K: the true slope is >= s; roots here have valuation >= s
            others = [sl for k, sl in enumerate(slopes) if k != e_idx]
            if n_e == 1 and all(s > o for o in others): distinct += 1
            else: flags.append('edge of length %d at index %d with unknown left valuation (K=%d) at depth %d' % (n_e, i0, K, depth))
            continue
        if E is not None and s * E <= v0:
            flags.append('tail may reach edge polynomial (slope %s, E=%d, v0=%d) at depth %d' % (s, E, v0, depth)); continue
        a_, b_ = s.numerator, s.denominator
        phi = [0] * (n_e // b_ + 1)
        for i in range(i0, i1 + 1):
            if (i - i0) % b_ == 0 and vals[i] == v0 - (i - i0) * a_ // b_:
                phi[(i - i0) // b_] = (g[i] // ell**vals[i]) % ell
        P, T = poly_mod_ell(phi, ell)
        if P.degree() <= 0: flags.append('degenerate edge polynomial at depth %d' % depth); continue
        if sp.gcd(P, P.diff(T)).degree() == 0:
            distinct += n_e; continue
        if b_ != 1:
            flags.append('repeated root on an edge of fractional slope %s at depth %d' % (s, depth)); continue
        roots = {int(r) % ell: m for r, m in P.ground_roots().items()}
        if sum(roots.values()) < P.degree():
            flags.append('repeated roots of the edge polynomial outside F_l at depth %d' % depth)
        for theta, mu in roots.items():
            if mu == 1: distinct += 1; continue
            # edge height H = v0 + s*i0 (Codex's correction): the common factor after eps = l^s (theta + tau) is l^H, not l^v0
            H = v0 + a_ * i0
            Knew = K - H if E is None else min(K - H, a_ * E - H)
            if Knew <= 1: flags.append('precision exhausted after refinement at depth %d' % depth); continue
            deg = len(g) - 1; h = [0] * (deg + 1)
            for i in range(deg + 1):
                if g[i] == 0: continue
                coef = g[i] * ell**(a_ * i)
                for k in range(i + 1): h[k] += coef * math.comb(i, k) * theta**(i - k)
            assert all(hk % ell**H == 0 for hk in h)
            h = [(hk // ell**H) % ell**Knew for hk in h]
            sub = separate(h, ell, Knew, None, depth + 1)
            if sub['L'] != mu: flags.append('refined local length %s differs from multiplicity %d at depth %d' % (sub['L'], mu, depth))
            distinct += sub['distinct']; flags += sub['flags']
    return {'L': L, 'distinct': distinct, 'flags': flags}

def analyse(g, ell, K, E):
    r = separate(g, ell, K, E); r['certified'] = (r['L'] is not None and r['distinct'] == r['L'] and not r['flags']); return r

if __name__ == '__main__':
    # regression: Codex's reproducer -- exact germ (t-13)^2 (1+t+...+t^7), jet of degree < 8; must NOT be certified as 2 distinct roots
    jet = [169, 143, 144, 144, 144, 144, 144, 144]
    for K in (6, 14):
        r = analyse(jet, 13, K, 8); print('Codex reproducer, K=%d:' % K, r)
        assert not r['certified'] and r['distinct'] < 2, 'FALSE POSITIVE'
    # sanity: exact polynomial with two distinct small roots 13 and 2*13, times a unit
    T = sp.Symbol('T'); poly = sp.Poly(sp.expand((T - 13) * (T - 26) * (1 + T + T**2)), T); coeffs = [int(poly.nth(k)) for k in range(poly.degree() + 1)]
    r = analyse(coeffs, 13, 12, None); print('exact (T-13)(T-26)(unit):', r); assert r['certified'] and r['L'] == 2
    # two roots +-sqrt(13): (T^2 - 13)(1+T)
    poly = sp.Poly(sp.expand((T**2 - 13) * (1 + T)), T); coeffs = [int(poly.nth(k)) for k in range(poly.degree() + 1)]
    r = analyse(coeffs, 13, 8, None); print('exact (T^2-13)(1+T):', r); assert r['certified']
    # a genuine double root as an exact polynomial: (T-13)^2 (1+T): must not certify
    poly = sp.Poly(sp.expand((T - 13)**2 * (1 + T)), T); coeffs = [int(poly.nth(k)) for k in range(poly.degree() + 1)]
    r = analyse(coeffs, 13, 12, None); print('exact (T-13)^2 (1+T):', r); assert not r['certified']
    poly = sp.Poly(sp.expand((T - 169) * (T - 13) * (T - 182)), T); coeffs = [int(poly.nth(k)) for k in range(poly.degree() + 1)]
    r = analyse(coeffs, 13, 14, None); print('exact (T-169)(T-13)(T-182) [Codex multi-edge case]:', r); assert r['certified'] and r['L'] == 3
    print('regression tests passed')

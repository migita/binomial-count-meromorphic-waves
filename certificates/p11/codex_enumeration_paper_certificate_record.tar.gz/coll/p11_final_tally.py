"""Final tally for X_11 at l=19: simple special points + corank-1 + corank-2 (first-generation batch, then v2 waves)."""
import pickle, glob, json
st = pickle.load(open('/tmp/fable/coll/stage1_p11.pkl', 'rb'))
rows = []
for f in sorted(glob.glob('/tmp/fable/coll/corank2_p11_chunk*.pkl')): rows += pickle.load(open(f, 'rb'))
v1 = {tuple(r['point']): r for r in rows}
v2 = {}
for f in sorted(glob.glob('/tmp/fable/coll/corank2v2_p11_wave*.pkl')):
    for r in pickle.load(open(f, 'rb')):
        k = tuple(r['point'])
        if k not in v2 or (r.get('complete') and not v2[k].get('complete')) or (not v2[k].get('complete') and r.get('certified_degree', 0) > v2[k].get('certified_degree', 0)): v2[k] = r
npres = {tuple(int(v) for v in a0): len(pr) for a0, cr, pr in st['singular'] if cr == 2}
assert set(v1) == set(npres), (len(v1), len(npres))
complete = incomplete = over = 0; cert = 0; residual = []
for key, n in npres.items():
    r = v1[key]
    if not r.get('complete') and key in v2: r = v2[key]
    d = r.get('certified_degree', 0)
    if r.get('over'): over += 1
    if r.get('complete'): complete += 1; cert += n
    else: incomplete += 1; cert += min(d, n); residual.append({'point': list(key), 'npres': n, 'certified': d, 'flags': r.get('flags', []), 'error': r.get('error')})
print('corank-2 special points: %d complete, %d incomplete, %d over; points certified %d of %d' % (complete, incomplete, over, cert, sum(npres.values())))
simple19 = 119781; simple361 = 87372; c1 = 97971
total = simple19 + simple361 + c1 + cert
print('X_11 grand total: %d + %d + %d + %d = %d of 352716' % (simple19, simple361, c1, cert, total))
json.dump(residual, open('/tmp/fable/coll/p11_residual_after_v2.json', 'w'), indent=1)
print('residual written:', len(residual))

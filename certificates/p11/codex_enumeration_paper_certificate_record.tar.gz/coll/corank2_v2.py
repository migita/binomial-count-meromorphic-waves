"""Second-generation corank-2 certification: Codex's tame local-field descent (codex_local_descent.py, via its JSON CLI) for every
univariate descent; second coordinate solved in the branch field or in a tame extension of it (with the embedding supplied by the
helper); strict Newton-Kantorovich certificate on the exact equations in the final field; orbit identification and degree by the
separable characteristic polynomial of a generic linear form of the certified coordinates.  Completeness = sum of orbit degrees
equals the local length (rigorous via the flatness total).  Candidate generation remains untrusted; only the final field-level
certificate and the separability test count."""
import numpy as np, sympy as sp, json, subprocess, math, sys, pickle, time, itertools
sys.path.insert(0, '/tmp/fable/coll'); sys.path.insert(0, '/home/amigita/projects/KS-260829'); sys.path.insert(0, '/tmp/ks-codex-series-deps')
import local_analysis as la
from lfield import LField
import corank2_certify as cc
from corank2_certify import linear_change, eval_jet_K, find_eps2, newton_kantorovich, eval_G_K, _divisible_by_e2, _shift_e2, valp
from hensel_certificate import derivative_terms_rat
CODEX_PY = '/tmp/ks-codex-localfields/bin/python'; CODEX_DESCENT = '/home/amigita/projects/KS-260829/codex_local_descent.py'

def field_def(K): return {'ell': K.ell, 'M': K.M, 'm': K.m, 'b': K.b, 'u': K.u}
def field_from_def(fd): return LField(fd['ell'], fd['M'], fd['m'], 1, fd['b'], fd['u'])
def arr(K, lst):
    z = K.zero(); z[...] = np.array(lst, dtype=object).reshape(K.b, K.f); return z % K.mod

def codex_descent(K, coeffs, known_valuation):
    req = {'field_def': field_def(K), 'coefficients': [[[int(x) for x in row] for row in c] for c in coeffs], 'known_valuation': int(known_valuation)}
    cp = subprocess.run([CODEX_PY, CODEX_DESCENT], input=json.dumps(req), capture_output=True, text=True, timeout=600, env={'PYTHONDONTWRITEBYTECODE': '1', 'PATH': '/usr/bin:/bin'})
    if cp.returncode != 0: return {'branches': [], 'flags': ['descent helper failed: ' + cp.stderr[-300:]]}
    return json.loads(cp.stdout)

def embed_via_images(Kold, Knew, x, base_basis_images):
    """map x in Kold (b x f array) into Knew using the images of the basis vectors zeta^j varpi^i (row i, col j)."""
    out = Knew.zero()
    for i in range(Kold.b):
        for j in range(Kold.f):
            c = int(x[i, j]) % Kold.mod
            if c:
                img = arr(Knew, base_basis_images[i][j]) if isinstance(base_basis_images[0][0][0], list) else arr(Knew, base_basis_images[i * Kold.f + j])
                out = Knew.add(out, Knew.scal(c, img))
    return out

def field_mulmat(K, x):
    """matrix of multiplication by x on the Z_l-basis {zeta^j varpi^i} (index i*f + j), size (b f) x (b f), entries mod l^M."""
    n = K.b * K.f; M = [[0] * n for _ in range(n)]
    for i in range(K.b):
        for j in range(K.f):
            e = K.zero(); e[i, j] = 1
            y = K.mul(x, e)
            for i2 in range(K.b):
                for j2 in range(K.f): M[i2 * K.f + j2][i * K.f + j] = int(y[i2, j2]) % K.mod
    return M

def orbit_key(K, a_cert, radius, weights=(3, 7, 11, 13, 17, 19, 23, 29, 31, 37)):
    """separable char poly of x = sum w_j a_j: returns (degree, charpoly tuple mod l^prec, separable, disc valuation)."""
    x = K.zero()
    for j, a in enumerate(a_cert): x = K.add(x, K.scal(weights[j % len(weights)], a))
    Mx = sp.Matrix(field_mulmat(K, x)); T = sp.Symbol('T')
    chi = Mx.charpoly(T); n = K.b * K.f
    disc = int(sp.discriminant(chi.as_expr(), T)) % K.mod
    prec = max(1, radius // K.b)                      # l-adic digits of the coefficients that the certificate guarantees
    vd = valp(disc, K.ell, K.M) if disc else K.M
    full = tuple(int(chi.coeff_monomial(T**k)) % K.mod for k in range(n + 1))
    return {'degree': n, 'charpoly': full, 'separable': vd < prec, 'disc_val': vd, 'prec': prec}

def same_orbit(o1, o2, ell):
    """two certified records represent provably different orbits iff their characteristic polynomials (common linear form) differ
    modulo ell^min(prec1, prec2); otherwise they are treated as the same orbit (conservative).  Different degrees: different."""
    if o1['degree'] != o2['degree']: return False
    m = ell**min(o1['prec'], o2['prec'])
    return all((a - b) % m == 0 for a, b in zip(o1['charpoly'], o2['charpoly']))

def certify_point_v2(st, a0, npres, K_ser=10, E_ser=12, M_field=24, c_list=(0, 3, 1, 5, 7), verbose=False):
    ell, d = st['ell'], st['p'] - 1; mod = ell**K_ser
    Gmod = [{m: (num * pow(den, -1, ell)) % ell for m, (num, den) in g.items()} for g in st['G']]
    Gd = [[derivative_terms_rat(g, j) for j in range(d)] for g in st['G']]
    def jac_mod(a0):
        J = [[0] * d for _ in range(d)]
        for r, g in enumerate(Gmod):
            for mono, c in g.items():
                for j, e in enumerate(mono):
                    if e:
                        v = c * e
                        for jj, ee in enumerate(mono): v = v * pow(int(a0[jj]), ee - 1 if jj == j else ee, ell)
                        J[r][j] = (J[r][j] + v) % ell
        return J
    J = jac_mod(a0); pr, pc, fc, ker = la.rank_pivots(J, ell); assert len(fc) == 2
    SerCls = cc._FastSer if cc._FastSer is not None else la.Ser
    Ev = la.Evaluator(d, ell, K_ser, SerCls(2, E_ser, mod))
    g1, g2 = la.local_series(Ev, Ev.S, a0, pr, pc, fc, ell, K_ser, J); avec = la.local_series.last_avec
    g1 = np.array(g1, dtype=object); g2 = np.array(g2, dtype=object); avec = [np.array(v, dtype=object) for v in avec]
    Q_l = LField(ell, K_ser, [0, 1], 1, 1, [1])
    best = None
    for c_change in c_list:
        g1t, g2t = linear_change(g1, c_change, mod), linear_change(g2, c_change, mod)
        avect = [linear_change(v, c_change, mod) for v in avec]
        out = {'npres': npres, 'c_change': c_change, 'orbits': {}, 'flags': [], 'branches_tried': 0}
        # components: exact-pulse split (jet divisible by eps2) handled as in v1
        components = []          # (g1c, g2c, e2_exact_zero)
        def split(gA, gB, depth=0):
            for g_div, g_oth in ((gA, gB), (gB, gA)):
                if _divisible_by_e2(g_div, mod):
                    components.append((g_oth, None, True))            # eps2 = 0: univariate g_oth(t, 0)
                    gq = _shift_e2(g_div, mod)
                    if any(int(x) % mod for x in gq.ravel()) and depth < 3: split(gq, g_oth, depth + 1)
                    return
            components.append((gA, gB, False))
        split(g1t, g2t)
        for gA, gB, exact0 in components:
            if exact0:
                poly = [int(gA[i, 0]) % mod for i in range(E_ser)]
                Kc = K_ser
            else:
                R = la.resultant_in_second(gA, gB, Ev.S, ell, K_ser, T=E_ser); R = [int(v) % mod for v in R]
                vals = [valp(c, ell, K_ser) for c in R]; kmin = min(vals); Kc = K_ser
                if 0 < kmin < K_ser: R = [(c // ell**kmin) % ell**(K_ser - kmin) for c in R]; Kc = K_ser - kmin
                poly = R
            Qc = LField(ell, Kc, [0, 1], 1, 1, [1])
            # exact zeros of t to precision: take t = 0 as its own branch (over Q_l) and descend on the cofactor for the rest
            k0 = 0
            while k0 < len(poly) - 1 and poly[k0] % ell**Kc == 0: k0 += 1
            branches_here = []
            if k0 > 0:
                branches_here.append({'field_def': field_def(Qc), 'root': [[0]], 'exact_zero_t': True})
                poly = poly[k0:]
            rep = codex_descent(Qc, [[[c]] for c in poly], Kc) if any(c % ell**Kc for c in poly) else {'branches': [], 'flags': []}
            out['flags'] += ['descent: ' + str(f) for f in rep.get('flags', [])]
            branches_here += rep.get('branches', [])
            for br in branches_here:
                out['branches_tried'] += 1
                Kb = field_from_def(dict(br['field_def'], M=M_field)); t_val = arr(Kb, br['root'])
                # second coordinate
                if exact0:
                    e2_list = [(Kb, t_val, Kb.zero(), None)]
                else:
                    cands, fl = find_eps2(Kb, gA, gB, t_val)
                    e2_list = [(Kb, t_val, e2, None) for e2, _ in cands[:4]]
                    if True:
                        # extension needed: descend on gA(t_val, eps2) over Kb via the helper
                        E = gA.shape[0]; P1 = [Kb.one()]
                        for i in range(1, E): P1.append(Kb.mul(P1[-1], t_val))
                        coeffs = []
                        for j in range(E):
                            acc = Kb.zero()
                            for i in range(E):
                                c_ = int(gA[i, j]) % Kb.mod
                                if c_: acc = Kb.add(acc, Kb.scal(c_, P1[i]))
                            coeffs.append(acc)
                        rep2 = codex_descent(Kb, coeffs, Kb.b * K_ser)
                        for br2 in rep2.get('branches', []):
                            K2 = field_from_def(dict(br2['field_def'], M=M_field)); e2n = arr(K2, br2['root'])
                            t_new = embed_via_images(Kb, K2, t_val, br2['base_basis_images'])
                            e2_list.append((K2, t_new, e2n, br2))
                        out['flags'] += ['eps2 descent: ' + str(f) for f in rep2.get('flags', [])]
                for Kx, tx, e2x, ext in e2_list:
                    a_star = [eval_jet_K(Kx, v, tx, e2x) for v in avect]
                    nk = newton_kantorovich(Kx, a_star, st['G'], Gd, verbose=verbose)
                    if not nk['ok']: continue
                    ok_red = all((int(nk['a'][j][0, 0]) - int(a0[j])) % ell == 0 for j in range(d))
                    if not ok_red: out['flags'].append('certified point does not reduce to a0'); continue
                    ok_ = orbit_key(Kx, nk['a'], nk['radius'])
                    if not ok_['separable']: out['flags'].append('linear form not separable at precision (deg %d, disc val %d, prec %d)' % (ok_['degree'], ok_['disc_val'], ok_['prec'])); continue
                    rec = {'degree': ok_['degree'], 'charpoly': ok_['charpoly'], 'prec': ok_['prec'], 'field_def': field_def(Kx), 'vF': nk['vF'], 'vdelta': nk['vdelta'], 'radius': nk['radius'],
                           'a_certified': [[[int(x) for x in row] for row in coord] for coord in nk['a']], 'extension': bool(ext is not None), 'disc_val': ok_['disc_val']}
                    if not any(same_orbit(rec, o, ell) for o in out['orbits'].values()):
                        out['orbits'][len(out['orbits'])] = rec
        total = sum(o['degree'] for o in out['orbits'].values())
        out['certified_degree'] = total; out['complete'] = (total == npres); out['over'] = total > npres
        if out['complete']: return out
        if best is None or total > best['certified_degree']: best = out
    return best

def run_batch(p, chunk, nchunks, only_points=None, tag='v2'):
    st = pickle.load(open('/tmp/fable/coll/stage1_p%d.pkl' % p, 'rb'))
    pts = [s_ for s_ in st['singular'] if s_[1] == 2]
    if only_points is not None:
        keyset = set(tuple(int(v) for v in q) for q in only_points); pts = [s_ for s_ in pts if tuple(int(v) for v in s_[0]) in keyset]
    pts = pts[chunk::nchunks]; results = []; t0 = time.time()
    for idx, (a0, cr, pres) in enumerate(pts):
        try: out = certify_point_v2(st, a0, len(pres))
        except Exception as e: out = {'error': repr(e), 'complete': False, 'npres': len(pres), 'certified_degree': 0}
        out['point'] = [int(v) for v in a0]; results.append(out)
        if (idx + 1) % 5 == 0: print('  %d/%d, %.0fs, complete %d, over %d' % (idx + 1, len(pts), time.time() - t0, sum(1 for r in results if r.get('complete')), sum(1 for r in results if r.get('over'))), flush=True)
    pickle.dump(results, open('/tmp/fable/coll/corank2%s_p%d_chunk%03d.pkl' % (tag, p, chunk), 'wb'))
    print('chunk %d done: %d points, complete %d, over %d, %.0fs' % (chunk, len(results), sum(1 for r in results if r.get('complete')), sum(1 for r in results if r.get('over')), time.time() - t0), flush=True)

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'residual8':
        import glob
        rows = []
        for f in sorted(glob.glob('/tmp/fable/coll/corank2_p8_chunk*.pkl')): rows += pickle.load(open(f, 'rb'))
        res2 = pickle.load(open('/tmp/fable/coll/corank2_p8_residual.pkl', 'rb'))
        done = {tuple(r['point']) for r in res2 if r.get('complete')} | {tuple(r['point']) for r in rows if r.get('complete')}
        inc = [r['point'] for r in rows if tuple(r['point']) not in done]
        print('residual p=8 points for v2:', len(inc), flush=True)
        run_batch(8, 0, 1, only_points=inc, tag='v2res')
    elif mode == 'batch':
        run_batch(int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]))

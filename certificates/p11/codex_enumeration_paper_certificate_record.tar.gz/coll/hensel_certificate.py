"""A-posteriori Hensel certificate over the finite algebra O' = Z_l[t]/(D(t)), D monic of degree L with integer coefficients.
Given an approximate point a* in O'^d (coordinates as polynomials in t of degree < L, integers mod l^M), and the exact equations
G_r = l * F_r (rational dicts), we compute in O' modulo l^M:  F = G(a*), J = dG/da (a*), delta = det J (Berkowitz, division-free),
then Newton steps a <- a - adj(J) F / delta (division by delta through the norm N(delta) = l^nu * unit, tracked exactly), and check
the Hensel-Rychlik condition F(a) in delta^2 O'^d, which certifies an exact root a_exact = a mod delta O'^d.  Distinctness of the L
embeddings: the characteristic polynomial chi of multiplication by a coordinate x of a_exact must have nonzero discriminant; we
compute chi from the refined a (which agrees with a_exact modulo delta), so disc(chi) is known modulo l^{M'} with
M' = M - 2*(L-1)*nu_delta ... conservatively we require disc(chi) != 0 modulo l^{v} for v = nu(delta) + 1 where nu(delta) bounds
the difference between a and a_exact per embedding (a_exact = a + delta*b): the roots of chi move by at most |delta|, so a nonzero
discriminant at valuation below the shift certifies distinct embeddings.  All quantities are integers; no truncation in t is involved."""
import numpy as np, sympy as sp, math, sys, pickle, time
from fractions import Fraction

class Alg:
    """Z/l^M [t]/(D), elements = lists of L ints."""
    def __init__(self, D, ell, M):
        self.D = [int(c) for c in D]; self.L = len(D) - 1; assert self.D[-1] == 1
        self.ell, self.M, self.mod = ell, M, ell**M
    def red(self, v):
        # reduce a polynomial (list low->high) modulo D and l^M
        v = [int(c) % self.mod for c in v]
        L = self.L
        for k in range(len(v) - 1, L - 1, -1):
            c = v[k]
            if c:
                for j in range(L + 1): v[k - L + j] = (v[k - L + j] - c * self.D[j]) % self.mod
        v = v[:L] + [0] * (L - len(v))
        return v
    def const(self, c): return [int(c) % self.mod] + [0] * (self.L - 1)
    def add(self, u, v): return [(a + b) % self.mod for a, b in zip(u, v)]
    def sub(self, u, v): return [(a - b) % self.mod for a, b in zip(u, v)]
    def mul(self, u, v):
        out = [0] * (2 * self.L - 1)
        for i, a in enumerate(u):
            if a:
                for j, b in enumerate(v): out[i + j] += a * b
        return self.red(out)
    def scal(self, k, u): return [(k * a) % self.mod for a in u]
    def is_zero(self, u): return all(a % self.mod == 0 for a in u)
    def mulmat(self, x):
        """L x L integer matrix of multiplication by x in the basis 1, t, ..., t^{L-1} (columns = x * t^j)."""
        cols = []
        e = self.const(1)
        for j in range(self.L):
            cols.append(self.mul(x, e)); e = self.red(e[:] and ([0] + e))  # e <- t*e
        return [[cols[j][i] for j in range(self.L)] for i in range(self.L)]
    def norm(self, x):
        return int(sp.Matrix(self.mulmat(x)).det()) % self.mod
    def val_int(self, n):
        n = int(n) % self.mod
        if n == 0: return self.M
        k = 0
        while n % self.ell == 0: n //= self.ell; k += 1
        return k
    def divide_exact(self, y, x):
        """y / x in O' if it exists: solve mulmat(x) * z = y over Z/l^M via adjugate: z = adj(Mx) y / N(x); requires l^{nu} | adj(Mx) y."""
        Mx = sp.Matrix(self.mulmat(x)); N = int(Mx.det()); nu = self.val_int(N)
        if nu >= self.M: return None, nu
        adj = Mx.adjugate()
        w = [int(sum(adj[i, j] * y[j] for j in range(self.L))) for i in range(self.L)]
        if any(wi % self.ell**nu for wi in w): return None, nu
        unit = (N // self.ell**nu) % self.mod
        inv = pow(unit, -1, self.mod)
        return [((wi // self.ell**nu) * inv) % self.mod for wi in w], nu

def eval_poly_alg(A, terms, avec):
    """terms: dict mono -> (num, den) rational; avec: list of O' elements. Returns O' element (den must be l-units)."""
    d = len(avec); acc = A.const(0)
    maxdeg = max(max(m) for m in terms)
    powers = [[A.const(1)] for _ in range(d)]
    for j in range(d):
        for e in range(1, maxdeg + 1): powers[j].append(A.mul(powers[j][-1], avec[j]))
    for mono, (num, den) in terms.items():
        c = (num * pow(den, -1, A.mod)) % A.mod
        t = A.const(c)
        for j, e in enumerate(mono):
            if e: t = A.mul(t, powers[j][e])
        acc = A.add(acc, t)
    return acc

def derivative_terms_rat(terms, j):
    out = {}
    for mono, (num, den) in terms.items():
        e = mono[j]
        if e == 0: continue
        m2 = list(mono); m2[j] -= 1; m2 = tuple(m2)
        if m2 in out:
            a, b = out[m2]; out[m2] = (a * den + num * e * b, b * den)
        else: out[m2] = (num * e, den)
    return out

def berkowitz_det(A, Mx):
    """determinant of a matrix with O'-entries (list of lists), division-free (Berkowitz)."""
    n = len(Mx); Z = A.const(0); ONE = A.const(1)
    def berk(Mx):
        n = len(Mx)
        if n == 1: return [ONE, A.sub(Z, Mx[0][0])]
        a = Mx[0][0]; R = Mx[0][1:]; C = [row[0] for row in Mx[1:]]; Sub = [row[1:] for row in Mx[1:]]
        diags = [C]
        for i in range(n - 2):
            prev = diags[-1]; nxt = []
            for r in range(n - 1):
                acc = Z
                for c_ in range(n - 1): acc = A.add(acc, A.mul(Sub[r][c_], prev[c_]))
                nxt.append(acc)
            diags.append(nxt)
        dvals = [ONE, A.sub(Z, a)]
        for dvec in diags:
            acc = Z
            for c_ in range(n - 1): acc = A.add(acc, A.mul(R[c_], dvec[c_]))
            dvals.append(A.sub(Z, acc))
        sub = berk(Sub)
        out = []
        for i in range(n + 1):
            acc = Z
            for j in range(n):
                if j <= i: acc = A.add(acc, A.mul(dvals[i - j], sub[j]))
            out.append(acc)
        return out
    vec = berk(Mx)
    return vec[-1] if n % 2 == 0 else A.sub(Z, vec[-1])

def adjugate_times(A, J, F):
    """adj(J) * F over O' via Cramer with Berkowitz determinants (n small)."""
    n = len(J); out = []
    for i in range(n):
        Mi = [[J[r][c] if c != i else F[r] for c in range(n)] for r in range(n)]
        out.append(berkowitz_det(A, Mi))
    return out

def certify(D, ell, M, a_star, G, max_newton=12, verbose=False):
    """Returns dict with keys: certified (bool), L, nu_delta, residual_val, disc_val, embeddings_distinct (bool), notes."""
    A = Alg(D, ell, M); d = len(a_star)
    a = [A.red([int(c) for c in coord]) for coord in a_star]
    Gd = [[derivative_terms_rat(g, j) for j in range(d)] for g in G]
    notes = []
    for it in range(max_newton):
        F = [eval_poly_alg(A, g, a) for g in G]
        J = [[eval_poly_alg(A, Gd[r][j], a) for j in range(d)] for r in range(d)]
        delta = berkowitz_det(A, J)
        Ndelta = A.norm(delta); nu = A.val_int(Ndelta)
        resid_vals = [A.val_int(A.norm(f)) if not A.is_zero(f) else A.M for f in F]      # valuations of norms (crude size measure)
        # Hensel-Rychlik test: F in delta^2 O'^d
        delta2 = A.mul(delta, delta)
        quotients = [A.divide_exact(f, delta2) for f in F]
        cond = all(q[0] is not None for q in quotients)
        if verbose: print('   it %d: nu(N delta)=%d, F norm valuations=%s, F in delta^2: %s' % (it, nu, resid_vals, cond), flush=True)
        if all(A.is_zero(f) for f in F):
            notes.append('residual vanished mod l^M at iteration %d' % it); cond = True
            break
        if cond and it > 0: break
        # Newton step: a <- a - adj(J) F / delta
        adjF = adjugate_times(A, J, F)
        step = [A.divide_exact(x, delta) for x in adjF]
        if any(s_[0] is None for s_ in step):
            notes.append('Newton step not divisible by delta at iteration %d' % it); break
        a = [A.sub(a[j], step[j][0]) for j in range(d)]
    F = [eval_poly_alg(A, g, a) for g in G]
    J = [[eval_poly_alg(A, Gd[r][j], a) for j in range(d)] for r in range(d)]
    delta = berkowitz_det(A, J); nu = A.val_int(A.norm(delta))
    delta2 = A.mul(delta, delta)
    cond = all(A.divide_exact(f, delta2)[0] is not None for f in F)
    res = {'L': A.L, 'nu_delta': nu, 'hensel_condition': cond, 'notes': notes}
    if not cond: res['certified'] = False; return res
    # distinctness: char poly of multiplication by a chosen coordinate (the one with largest spread): use x = a[d-1] + 3*a[0] etc.
    best = None
    for coord in [a[-1]] + a[:-1] + [A.add(a[-1], A.scal(7, a[0]))]:
        Mx = sp.Matrix(A.mulmat(coord)); T = sp.Symbol('T')
        chi = Mx.charpoly(T); disc = int(sp.discriminant(chi.as_expr(), T)) % A.mod
        v = A.val_int(disc)
        if best is None or v < best[0]: best = (v, coord)
    disc_val = best[0]
    # a_exact = a + delta*b: embeddings of the coordinate move by at most |delta| (valuation nu per embedding in the worst case);
    # the discriminant of L values with pairwise valuations of differences < shift is unchanged in valuation if
    # v(disc) < 2 * (number of pairs) * nu ... we use the conservative criterion: certified distinct iff disc_val <= nu (each pairwise
    # difference then has valuation <= nu/ (1) < nu is not implied); instead require disc_val < nu when nu > 0, else disc_val < M.
    res['disc_val'] = disc_val
    res['embeddings_distinct'] = (disc_val < A.M) and (nu == 0 or disc_val < nu)
    res['certified'] = res['embeddings_distinct']
    return res

if __name__ == '__main__':
    print('module loaded')

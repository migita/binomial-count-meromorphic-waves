import pickle, sys, json, time
sys.path.insert(0, '/tmp/fable/coll')
import corank2_v2 as v2
a0 = json.loads(sys.argv[1]); K_ser, E_ser, M_field = int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
st = pickle.load(open('/tmp/fable/coll/stage1_p11.pkl', 'rb'))
npres = {tuple(int(v) for v in q): len(pr) for q, cr, pr in st['singular'] if cr == 2}[tuple(a0)]
t0 = time.time(); out = v2.certify_point_v2(st, a0, npres, K_ser=K_ser, E_ser=E_ser, M_field=M_field)
out['point'] = a0
print('HP point', a0, 'npres', npres, 'certified', out['certified_degree'], 'complete', out['complete'], 'over', out['over'], 'c', out.get('c_change'), '%.0fs' % (time.time() - t0))
for k, o in out['orbits'].items(): print(' orbit', k, 'deg', o['degree'], 'prec', o['prec'], 'disc_val', o['disc_val'], 'vF', o['vF'], 'vdelta', o['vdelta'])
from collections import Counter; print(Counter(str(f)[:120] for f in out.get('flags', [])))
pickle.dump([out], open('/tmp/fable/coll/corank2v2_p11_wavehp_pt%s.pkl' % '_'.join(str(v) for v in a0), 'wb'))

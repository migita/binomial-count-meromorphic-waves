"""Exact arithmetic in a local field K = Q_l(zeta)(pi): W = Z_l[zeta]/(m(zeta)) unramified of degree f (m monic, irreducible mod l),
pi^b = l^a * u with u a unit of W and gcd(a,b) = 1 (so K/Q_l(zeta) is totally ramified of degree b and O_K = W[pi]).
Elements are pairs (X, e) meaning l^{-e} X with X in O_K stored as a b x f integer array modulo l^M (row i = coefficient of pi^i in W).
Valuation normalised by v(l) = b, v(pi) = a (so the value group is Z when gcd(a,b)=1)."""
import numpy as np, sympy as sp

class LField:
    def __init__(self, ell, M, m_coeffs, a, b, u):
        self.ell, self.M, self.mod = ell, M, ell**M
        self.m = [int(c) for c in m_coeffs]; self.f = len(self.m) - 1; assert self.m[-1] == 1
        self.a, self.b = a, b; assert a == 1, 'construct fields with an Eisenstein uniformizer (a=1): varpi^b = l*u'
        self.u = [int(c) % self.mod for c in u] + [0] * (self.f - len(u))          # element of W (list of f ints)
        assert self.wval(self.u) == 0, 'u must be a unit of W'
        self.ell_a = ell**a
    # ---------- W arithmetic (lists of f ints) ----------
    def wred(self, v):
        v = [int(c) % self.mod for c in v]; f = self.f
        for k in range(len(v) - 1, f - 1, -1):
            c = v[k]
            if c:
                for j in range(f + 1): v[k - f + j] = (v[k - f + j] - c * self.m[j]) % self.mod
        return v[:f] + [0] * (f - len(v))
    def wmul(self, x, y):
        out = [0] * (2 * self.f - 1)
        for i, xi in enumerate(x):
            if xi:
                for j, yj in enumerate(y): out[i + j] += xi * yj
        return self.wred(out)
    def wadd(self, x, y): return [(p + q) % self.mod for p, q in zip(x, y)]
    def wval(self, x):                                   # l-adic valuation of an element of W (unramified: min over coefficients)
        best = self.M
        for c in x:
            c = int(c) % self.mod
            if c == 0: continue
            k = 0
            while c % self.ell == 0: c //= self.ell; k += 1
            best = min(best, k)
        return best
    def winv_unit(self, x):
        """inverse of a unit of W: invert modulo (l, m) in F_{l^f} then Newton-lift."""
        zeta = sp.Symbol('z'); P = sp.Poly(sum(int(c) * zeta**k for k, c in enumerate(x)), zeta, modulus=self.ell)
        Mm = sp.Poly(sum(c * zeta**k for k, c in enumerate(self.m)), zeta, modulus=self.ell)
        inv0 = sp.invert(P, Mm)
        z = [int(inv0.coeff_monomial(zeta**k)) % self.ell for k in range(self.f)] + [0] * 0
        z = (z + [0] * self.f)[:self.f]
        two = [2] + [0] * (self.f - 1)
        for _ in range(self.M.bit_length() + 1):
            z = self.wmul(z, [(p - q) % self.mod for p, q in zip(two, self.wmul(x, z))])
        return z
    # ---------- O_K elements: b x f arrays ----------
    def zero(self): return np.zeros((self.b, self.f), dtype=object)
    def one(self):
        z = self.zero(); z[0, 0] = 1; return z
    def from_int(self, c):
        z = self.zero(); z[0, 0] = int(c) % self.mod; return z
    def from_w(self, w):
        z = self.zero(); z[0, :] = [int(c) % self.mod for c in w]; return z
    def pi(self):
        z = self.zero()
        if self.b > 1: z[1, 0] = 1
        else: z[0, :] = [(self.ell_a * c) % self.mod for c in self.u]        # b = 1: pi = l^a u
        return z
    def add(self, X, Y): return (X + Y) % self.mod
    def sub(self, X, Y): return (X - Y) % self.mod
    def scal(self, c, X): return (int(c) * X) % self.mod
    def mul(self, X, Y):
        b, f = self.b, self.f
        acc = [[0] * f for _ in range(2 * b - 1)]
        for i in range(b):
            if not any(X[i]): continue
            for j in range(b):
                if not any(Y[j]): continue
                prod = self.wmul(list(X[i]), list(Y[j]))
                acc[i + j] = self.wadd(acc[i + j], prod)
        # reduce pi^k for k >= b: pi^k = pi^{k-b} * l^a u
        out = self.zero()
        for k in range(2 * b - 2, -1, -1):
            row = acc[k]
            if not any(row): continue
            if k >= b:
                add = self.wmul(row, [(self.ell_a * c) % self.mod for c in self.u])
                acc[k - b] = self.wadd(acc[k - b], add)
            else:
                out[k, :] = row
        return out % self.mod
    def val(self, X):                                    # valuation with v(l)=b, v(pi)=a ; +infinity encoded as b*M
        best = self.b * self.M
        for i in range(self.b):
            wv = self.wval(list(X[i]))
            if wv < self.M: best = min(best, self.a * i + self.b * wv)
        return best
    def is_zero(self, X): return self.val(X) >= self.b * self.M
    def eval_poly(self, coeffs, X):                      # coeffs: ints or W-lists (low->high)
        acc = self.zero(); P = self.one()
        for c in coeffs:
            C = self.from_w(c) if isinstance(c, (list, tuple)) else self.from_int(c)
            acc = self.add(acc, self.mul(C, P)); P = self.mul(P, X)
        return acc
    # ---------- units and division ----------
    def unit_inverse(self, X):
        """inverse of a unit X of O_K (val 0): invert the residue in F_{l^f} = O_K/pi, then Newton-lift z <- z(2 - Xz)."""
        assert self.val(X) == 0
        z0 = self.winv_unit(list(X[0]))
        z = self.from_w(z0); two = self.from_int(2)
        for _ in range(2 * (self.M * self.b).bit_length() + 2):
            z = self.mul(z, self.sub(two, self.mul(X, z)))
        return z
    def uniformizer_powers(self):
        """(i0, j0) with a*i0 + b*j0 = 1: varpi = pi^i0 * l^j0 (j0 may be negative)."""
        from sympy import gcdex
        s, t, g = gcdex(self.a, self.b)          # s*a + t*b = 1
        return int(s), int(t)
    def divide(self, X, Y):
        """X / Y for Y != 0 with v(X) >= v(Y); result in O_K, exact modulo l^{M - (loss)}. Returns (Z, lost_digits)."""
        vY = self.val(Y); vX = self.val(X); assert vX >= vY, 'not divisible in O_K'
        i0, j0 = self.uniformizer_powers()
        # write Y = varpi^{vY} * unit:  compute unit = Y * varpi^{-vY} = Y * pi^{-i0 vY} * l^{-j0 vY}
        # multiplication by pi^{-1} = pi^{b-1} / (l^a u): we implement Y * pi^{-k} by repeated (Y * pi^{b-1} * u^{-1}) / l^a
        def div_by_l(Z, k):                              # exact division of an O_K element by l^k
            out = Z.copy()
            for i in range(self.b):
                for j in range(self.f):
                    c = int(out[i, j]) % self.mod
                    assert c % self.ell**k == 0, 'not divisible by l^k'
                    out[i, j] = c // self.ell**k
            return out % (self.mod // self.ell**k)
        def times_pi_power(Z, k):                        # Z * pi^k for integer k (negative allowed when divisible)
            if k >= 0:
                P = self.one(); pi = self.pi()
                for _ in range(k): P = self.mul(P, pi)
                return self.mul(Z, P), 0
            uinv = self.unit_inverse(self.from_w(self.u)); lost = 0
            for _ in range(-k):
                Z = self.mul(Z, self.eval_poly([0] * (self.b - 1) + [1], self.pi()) if self.b > 1 else self.one())  # Z * pi^{b-1}
                Z = self.mul(Z, uinv); Z = div_by_l(Z, self.a); lost += self.a
            return Z, lost
        lost_total = 0
        U, lost = times_pi_power(Y, -i0 * vY); lost_total += lost
        if j0 * vY > 0: U = div_by_l(U, j0 * vY); lost_total += j0 * vY
        elif j0 * vY < 0: U = self.scal(self.ell**(-j0 * vY), U)
        assert self.val(U) == 0, 'unit extraction failed'
        Uinv = self.unit_inverse(U)
        Z = self.mul(X, Uinv)                            # X / unit
        Z, lost = times_pi_power(Z, -i0 * vY); lost_total += lost
        if j0 * vY > 0: Z = div_by_l(Z, j0 * vY); lost_total += j0 * vY
        elif j0 * vY < 0: Z = self.scal(self.ell**(-j0 * vY), Z)
        return Z, lost_total

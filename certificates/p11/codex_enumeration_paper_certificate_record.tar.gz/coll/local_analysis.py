"""Stage 2: l-adic local analysis at the singular special points (corank 1 and 2).
At a singular point a0 (mod l): choose pivot equations I and pivot coordinates T with invertible block dG_I/da_T mod l; the free
coordinates F (|F| = corank c) are parametrised by eps; y(eps) solves G_I = 0 by simplified Newton over Z/l^K[[eps]] truncated at
total degree E; the remaining c equations give series g_i(eps).  c = 1: Hensel-factor g = D*U, D distinguished of degree L (= local
length); D squarefree (disc(D) != 0 mod l^K) <=> L distinct characteristic-zero points near a0.  c = 2: random linear change, resultant
in eps_2 -> univariate series in eps_1, then the c = 1 analysis.  Evaluations use G = l*rem_A(H_A) with H_A = sum A_i A_j Phi_ij(x)."""
import sympy as sp, numpy as np, pickle, sys, time, math, random, itertools, json
sys.path.insert(0, '/tmp/fable'); sys.path.insert(0, '/tmp/fable/coll')
from audit_congruence import faulhaber, x, n as nsym

# ---------- truncated power series over Z/mod in c variables as numpy int64 arrays (c=1: shape (E,), c=2: shape (E,E)) -------
class Ser:
    def __init__(self, c, E, mod):
        self.c, self.E, self.mod = c, E, mod
        self.dt = np.int64 if (E**c) * mod * mod < 2**62 else object
    def zero(self):
        z = np.zeros((self.E,) * self.c, dtype=self.dt)
        if self.dt is object: z[...] = 0
        return z
    def const(self, v):
        z = self.zero(); z[(0,) * self.c] = v % self.mod; return z
    def var(self, i, coeff=1):
        z = self.zero(); idx = [0] * self.c; idx[i] = 1; z[tuple(idx)] = coeff % self.mod; return z
    def add(self, u, v): return (u + v) % self.mod
    def sub(self, u, v): return (u - v) % self.mod
    def scal(self, k, u): return (k % self.mod) * u % self.mod
    def mul(self, u, v):
        E = self.E
        if self.c == 1:
            return np.convolve(u, v)[:E] % self.mod
        out = self.zero()
        for i in range(E):
            if not u[i].any(): continue
            for j in range(E - i):
                # out[i+j, :] += u[i,:] (*) v[j,:]  (1-D convolution along the second axis, truncated)
                out[i + j] = (out[i + j] + np.convolve(u[i], v[j])[:E]) % self.mod
        return out
    def truncate_total(self, u):
        if self.c == 1: return u
        E = self.E; out = u.copy()
        for i in range(E):
            out[i, E - i:] = 0
        return out

def phi_polys(d, ell, K):
    """ell * Phi_ij(x) mod ell^K as integer coefficient lists (low -> high), Phi_ij(n) = sum_{s=1}^{n-1} s^i (n-s)^j."""
    mod = ell**K
    F = [faulhaber(k) for k in range(2 * d + 1)]; F[0] = F[0] - 1
    Phi = {}
    for i in range(d + 1):
        for j in range(d + 1):
            expr = sum(sp.binomial(j, t) * nsym**(j - t) * (-1)**t * F[i + t] for t in range(j + 1))
            P = sp.Poly(sp.expand(expr * ell), nsym)
            coeffs = []
            for k in range(i + j + 2):
                c = sp.Rational(P.coeff_monomial(nsym**k)); num, den = int(c.p), int(c.q)
                assert den % ell != 0, ('ell*Phi not ell-integral', i, j, k, c)
                coeffs.append((num * pow(den, -1, mod)) % mod)
            Phi[(i, j)] = coeffs
    return Phi

class Evaluator:
    """G(a) = ell * rem_A(H_A) evaluated at series-valued a (list of d series, a_1..a_d), using precomputed ell*Phi_ij."""
    def __init__(self, d, ell, K, S):
        self.d, self.ell, self.S = d, ell, S; self.mod = ell**K
        self.Phi = phi_polys(d, ell, K)
    def G(self, avec):
        d, S = self.d, self.S
        # A coefficients low->high: A_0 = a_d, ..., A_{d-1} = a_1, A_d = 1
        A = [avec[d - 1 - k] for k in range(d)] + [S.const(1)]
        # ell*H_A = sum_{i,j} A_i A_j (ell Phi_ij)(x): polynomial in x of degree 2d+1 with series coefficients
        H = [S.zero() for _ in range(2 * d + 2)]
        prod = {}
        for i in range(d + 1):
            for j in range(i, d + 1):
                pij = S.mul(A[i], A[j]) if i != j else S.mul(A[i], A[i])
                coeffs = self.Phi[(i, j)]
                factor = 2 if i != j else 1                    # Phi_ij = Phi_ji
                for k, c in enumerate(coeffs):
                    if c: H[k] = (H[k] + (factor * c) % self.mod * pij) % self.mod
        # remainder of H (deg 2d+1) modulo monic A (deg d): long division with series coefficients
        R = [h.copy() for h in H]
        for k in range(2 * d + 1, d - 1, -1):
            lead = R[k]
            if not lead.any(): continue
            for t in range(d + 1):
                R[k - d + t] = (R[k - d + t] - S.mul(lead, A[t])) % self.mod
        return R[:d]                                             # G_0..G_{d-1} as series

def rank_pivots(J, ell):
    """Gaussian elimination mod ell; returns pivot rows, pivot cols, kernel basis (as integer vectors mod ell)."""
    M = [[int(v) % ell for v in row] for row in J]; nrow, ncol = len(M), len(M[0])
    piv_rows, piv_cols = [], []; row = 0; M2 = [r[:] for r in M]; used_rows = []
    # track original row indices through swaps
    order = list(range(nrow))
    for col in range(ncol):
        piv = next((i for i in range(row, nrow) if M2[i][col] % ell), None)
        if piv is None: continue
        M2[row], M2[piv] = M2[piv], M2[row]; order[row], order[piv] = order[piv], order[row]
        inv = pow(M2[row][col], -1, ell); M2[row] = [(v * inv) % ell for v in M2[row]]
        for i in range(nrow):
            if i != row and M2[i][col]:
                f = M2[i][col]; M2[i] = [(vi - f * vr) % ell for vi, vr in zip(M2[i], M2[row])]
        piv_cols.append(col); piv_rows.append(order[row]); row += 1
        if row == nrow: break
    free_cols = [c for c in range(ncol) if c not in piv_cols]
    kernel = []
    for fc in free_cols:
        v = [0] * ncol; v[fc] = 1
        for r_i, pc in enumerate(piv_cols):
            v[pc] = (-M2[r_i][fc]) % ell
        kernel.append(v)
    return piv_rows, piv_cols, free_cols, kernel

def mat_inv_mod(M, mod):
    """inverse of an integer matrix modulo mod = ell^K (M invertible mod ell), via Newton lifting from mod ell."""
    n = len(M); ell = None
    Mi = sp.Matrix(M)
    # inverse mod the prime first (sympy), then lift: X <- X(2I - M X)
    return Mi

def series_jacobian_free(Ev, S, a0, piv_rows, piv_cols, free_cols, ell, mod, E, iters):
    pass

def local_series(Ev, S, a0, piv_rows, piv_cols, free_cols, ell, K, Jmod):
    """Parametrise the local scheme by eps (free coordinates), solve pivot equations by simplified Newton, return dependent series."""
    d = Ev.d; mod = ell**K; c = len(free_cols)
    dep_rows = [r for r in range(d) if r not in piv_rows]
    # inverse of the pivot block mod ell^K (lift the mod-ell inverse by Newton iteration X <- X(2I - B X))
    B = np.array([[Jmod[r][t] for t in piv_cols] for r in piv_rows], dtype=object)
    Bl = sp.Matrix(B.tolist()); X = np.array(Bl.inv_mod(ell).tolist(), dtype=object)
    I = np.identity(len(piv_rows), dtype=object)
    for _ in range(K.bit_length() + 1):
        X = (X.dot(2 * I - B.dot(X))) % mod
    Xn = np.array(X.tolist(), dtype=S.dt)
    # coordinates as series: free: a0 + eps_i ; pivot: a0 + y (unknown, start 0)
    avec = [S.const(int(a0[j])) for j in range(d)]
    for i, fc in enumerate(free_cols):
        avec[fc] = S.add(avec[fc], S.var(i))
    y = [S.zero() for _ in piv_cols]
    import time as _t
    for it in range(2 * (S.E + K) + 4):
        _t0 = _t.time()
        G = Ev.G(avec)
        res = [G[r] for r in piv_rows]
        if getattr(local_series, 'verbose', False): print('    newton it %d: G eval %.3fs, residual nonzero entries %s' % (it, _t.time() - _t0, [int(np.count_nonzero(r_)) for r_ in res]), flush=True)
        if all(not r_.any() for r_ in res): break
        # y <- y - X * res   (X constant inverse block)
        for ti in range(len(piv_cols)):
            delta = S.zero()
            for ri in range(len(piv_rows)):
                if Xn[ti, ri]: delta = (delta + Xn[ti, ri] * res[ri]) % mod
            y[ti] = (y[ti] - delta) % mod
            avec[piv_cols[ti]] = (S.const(int(a0[piv_cols[ti]])) + y[ti]) % mod
    G = Ev.G(avec)
    assert all(not G[r].any() for r in piv_rows), 'Newton did not converge'
    local_series.last_avec = avec
    return [G[r] for r in dep_rows]

# ---------- univariate l-adic root separation via Newton polygons ----------
def val(vv, ell, cap):
    vv = int(vv)
    if vv == 0: return cap
    k = 0
    while vv % ell == 0 and k < cap: vv //= ell; k += 1
    return k

def polyroots_mod(phi, ell):
    """roots in F_ell of a polynomial with int coeffs (low->high); returns dict root->multiplicity (over F_ell only)."""
    xs = sp.Symbol('T'); P = sp.Poly(sum(int(c) * xs**k for k, c in enumerate(phi)), xs, modulus=ell)
    if P.is_zero: return {}
    return {int(r) % ell: m for r, m in P.ground_roots().items()}

def is_squarefree_mod(phi, ell):
    xs = sp.Symbol('T'); P = sp.Poly(sum(int(c) * xs**k for k, c in enumerate(phi)), xs, modulus=ell)
    if P.degree() <= 0: return True
    return sp.gcd(P, P.diff(xs)).degree() == 0

def separate_small_roots(g, ell, K, depth=0):
    """g: int coeffs low->high, known modulo ell^K.  Count the roots with positive valuation (in Q_ell-bar), with multiplicity
    (L) and how many are certified distinct.  Returns dict(L, distinct, flags)."""
    mod = ell**K
    g = [int(v) % mod for v in g]
    vals = [val(c, ell, K) for c in g]
    L = next((k for k, v in enumerate(vals) if v == 0), None)
    if L is None: return {'L': None, 'distinct': 0, 'flags': ['g vanishes mod ell to truncation (precision/truncation too small)']}
    if L == 0: return {'L': 0, 'distinct': 0, 'flags': []}
    # lower convex hull of (i, vals[i]) for i = 0..L  (negative slopes only)
    pts = [(i, vals[i]) for i in range(L + 1)]
    hull = [pts[0]]
    for pt in pts[1:]:
        while len(hull) >= 2:
            (x1, y1), (x2, y2) = hull[-2], hull[-1]; x3, y3 = pt
            if (y2 - y1) * (x3 - x1) >= (y3 - y1) * (x2 - x1): hull.pop()
            else: break
        hull.append(pt)
    distinct = 0; flags = []
    for (i0, v0), (i1, v1) in zip(hull, hull[1:]):
        n_e = i1 - i0
        if v0 >= K:   # coefficient not known to be nonzero at this precision: a single root of valuation >= K-1 is still a distinct root
            if n_e == 1: distinct += 1
            else: flags.append('edge of length %d from index %d has unknown valuation (precision)' % (n_e, i0))
            continue
        num, den = v0 - v1, n_e; gcd_ = math.gcd(num, den); a_, b_ = num // gcd_, den // gcd_      # slope -a_/b_
        # edge polynomial phi(T) with T = (eps / ell^{a_/b_})^{b_}
        phi = [0] * (n_e // b_ + 1)
        for i in range(i0, i1 + 1):
            if (i - i0) % b_ == 0:
                vi_expected = v0 - (i - i0) * a_ // b_
                if vals[i] == vi_expected:
                    phi[(i - i0) // b_] = (g[i] // ell**vi_expected) % ell
        if is_squarefree_mod(phi, ell):
            distinct += n_e; continue
        if b_ != 1:
            flags.append('non-squarefree edge polynomial with fractional slope %d/%d at depth %d' % (a_, b_, depth)); continue
        s_ = a_
        # refine around each F_ell root theta of phi with multiplicity mu (roots outside F_ell: flag)
        roots = polyroots_mod(phi, ell); covered = 0
        for theta, mu in roots.items():
            covered += mu
            if mu == 1: distinct += 1; continue
            # substitute eps = ell^s (theta + tau); divide by ell^{v0}; recurse on small roots of h(tau)
            Knew = K - v0
            if Knew <= 1: flags.append('precision exhausted at depth %d' % depth); continue
            # h(tau) = g(ell^s (theta + tau)) / ell^{v0}: compute exactly with Python ints then reduce mod ell^Knew
            deg = len(g) - 1
            # expand sum_i g_i ell^{s i} (theta + tau)^i
            h = [0] * (deg + 1)
            for i in range(deg + 1):
                if g[i] == 0: continue
                coef = g[i] * ell**(s_ * i)
                # (theta + tau)^i binomial expansion
                for k in range(i + 1):
                    h[k] += coef * math.comb(i, k) * theta**(i - k)
            assert all(hk % ell**v0 == 0 for hk in h), 'refinement division error'
            h = [(hk // ell**v0) % ell**Knew for hk in h]
            sub = separate_small_roots(h, ell, Knew, depth + 1)
            if sub['L'] != mu: flags.append('refined multiplicity mismatch %s vs %d' % (sub['L'], mu))
            distinct += sub['distinct']; flags += sub['flags']
        if covered < sum(1 for _ in range(n_e)) and covered != n_e:
            deg_phi = len(phi) - 1
            if covered < deg_phi: flags.append('edge polynomial has repeated roots outside F_ell (depth %d)' % depth)
    return {'L': L, 'distinct': distinct, 'flags': flags}

def analyse_univariate(g, ell, K, label=''):
    res = separate_small_roots([int(v) for v in g], ell, K)
    res['distinct_all'] = (res['L'] is not None and res['distinct'] == res['L'] and not res['flags'])
    return res

def resultant_in_second(g1, g2, S, ell, K, T=None):
    """Res_{eps2}(g1, g2) modulo (ell^K, eps1^T) via a division-free Berkowitz determinant of the Sylvester matrix whose entries
    are truncated series in eps1 (numpy int64 arrays).  g1, g2: (E,E) arrays [i,j] <-> eps1^i eps2^j."""
    mod = ell**K; E = S.E; T = T or E
    def col(g, j):                       # coefficient of eps2^j as series in eps1 (length T)
        v = np.zeros(T, dtype=S.dt); v[:min(E, T)] = g[:min(E, T), j] % mod; return v
    def deg2(g):
        for j in range(E - 1, -1, -1):
            if g[:, j].any(): return j
        return -1
    m1, m2 = deg2(g1), deg2(g2)
    if m1 < 0 or m2 < 0: return [0]
    n = m1 + m2
    Z = np.zeros(T, dtype=S.dt); ONE = Z.copy(); ONE[0] = 1
    Mx = [[Z.copy() for _ in range(n)] for _ in range(n)]
    for i in range(m2):
        for k in range(m1 + 1): Mx[i][i + k] = col(g1, m1 - k)
    for i in range(m1):
        for k in range(m2 + 1): Mx[m2 + i][i + k] = col(g2, m2 - k)
    smul = lambda u, v: np.convolve(u, v)[:T] % mod
    def berkowitz(Mx):
        n = len(Mx)
        if n == 0: return [ONE.copy()]
        if n == 1: return [ONE.copy(), (-Mx[0][0]) % mod]
        a = Mx[0][0]; R = Mx[0][1:]; C = [row[0] for row in Mx[1:]]; A = [row[1:] for row in Mx[1:]]
        diags = [C]
        for i in range(n - 2):
            prev = diags[-1]; nxt = []
            for r in range(n - 1):
                acc = Z.copy()
                for c_ in range(n - 1):
                    if A[r][c_].any() and prev[c_].any(): acc = (acc + smul(A[r][c_], prev[c_])) % mod
                nxt.append(acc)
            diags.append(nxt)
        dvals = [ONE.copy(), (-a) % mod]
        for dvec in diags:
            acc = Z.copy()
            for c_ in range(n - 1):
                if R[c_].any() and dvec[c_].any(): acc = (acc + smul(R[c_], dvec[c_])) % mod
            dvals.append((-acc) % mod)
        sub = berkowitz(A)                    # length n
        out = []
        for i in range(n + 1):
            acc = Z.copy()
            for j in range(n):
                if j <= i and dvals[i - j].any() and sub[j].any(): acc = (acc + smul(dvals[i - j], sub[j])) % mod
            out.append(acc)
        return out
    vec = berkowitz(Mx)                        # characteristic polynomial coefficients; det = (-1)^n * last
    det = vec[-1] if n % 2 == 0 else (-vec[-1]) % mod
    return [int(v) for v in det]

if __name__ == '__main__':
    p = int(sys.argv[1]); K = int(sys.argv[2]) if len(sys.argv) > 2 else 6; E = int(sys.argv[3]) if len(sys.argv) > 3 else 8
    st = pickle.load(open('/tmp/fable/coll/stage1_p%d.pkl' % p, 'rb'))
    ell, d = st['ell'], p - 1; mod = ell**K
    Gterms = [{m: (num, den) for m, (num, den) in g.items()} for g in st['G']]
    Gmod = [{m: (num * pow(den, -1, ell)) % ell for m, (num, den) in g.items()} for g in Gterms]
    def jac_mod(a0):
        J = [[0] * d for _ in range(d)]
        for r, g in enumerate(Gmod):
            for mono, c in g.items():
                for j, e in enumerate(mono):
                    if e:
                        v = c * e
                        for jj, ee in enumerate(mono):
                            if jj == j: v = v * pow(int(a0[jj]), ee - 1, ell)
                            else: v = v * pow(int(a0[jj]), ee, ell)
                        J[r][j] = (J[r][j] + v) % ell
        return J
    from separator import analyse as tail_aware_analyse
    Ev = {}
    def get_ev(c, Kk, Ee):
        if (c, Kk, Ee) not in Ev: Ev[(c, Kk, Ee)] = Evaluator(d, ell, Kk, Ser(c, Ee, ell**Kk))
        return Ev[(c, Kk, Ee)]
    def analyse_point(a0, cr, Kk, Ee):
        J = jac_mod(a0); piv_rows, piv_cols, free_cols, kernel = rank_pivots(J, ell)
        assert len(free_cols) == cr
        if cr == 1:
            E_ = get_ev(1, Kk, Ee)
            g = local_series(E_, E_.S, a0, piv_rows, piv_cols, free_cols, ell, Kk, J)[0]
            r = tail_aware_analyse([int(v) for v in g], ell, Kk, Ee); r['K'] = Kk; r['E'] = Ee; return r
        return {'L': None, 'distinct': 0, 'flags': ['corank %d: rigorous method pending' % cr], 'certified': False}
    schedule = [(7, 8), (16, 16), (24, 28)]           # (K, E): int64 first, then arbitrary precision
    only_corank = int(sys.argv[4]) if len(sys.argv) > 4 else 1
    t0 = time.time(); results = []; stats = {}; unresolved = []; total_L = 0; escalations = 0
    todo = [(a0, cr, pr) for a0, cr, pr in st['singular'] if cr == only_corank]
    chunk, nchunks = (int(sys.argv[5]), int(sys.argv[6])) if len(sys.argv) > 6 else (0, 1)
    todo = todo[chunk::nchunks]
    for idx, (a0, cr, presentations) in enumerate(todo):
        res = None
        for Kk, Ee in schedule:
            res = analyse_point(a0, cr, Kk, Ee)
            if res.get('certified'): break
            escalations += 1
        res['corank'] = cr; res['npres'] = len(presentations); res['point'] = tuple(int(v) for v in a0)
        results.append(res)
        L = res.get('L')
        if L is not None: total_L += L
        key = 'corank%d' % cr
        tag = ('L=%s' % L) + (',certified' if res.get('certified') else ',NOT-certified') + (',npres=%d' % len(presentations)) + (',L!=npres' if L is not None and L != len(presentations) else '')
        stats.setdefault(key, {})[tag] = stats.setdefault(key, {}).get(tag, 0) + 1
        if not res.get('certified'): unresolved.append(res)
        if (idx + 1) % 100 == 0: print('  %d/%d points, %.0fs, escalations %d, not certified %d' % (idx + 1, len(todo), time.time() - t0, escalations, len(unresolved)), flush=True)
    print('stats:', json.dumps(stats, indent=1))
    print('sum of local lengths over analysed points: %d (presentations there: %d)' % (total_L, sum(len(pr) for _, _, pr in todo)))
    print('not certified: %d' % len(unresolved))
    for r in unresolved[:10]: print('  ', {k: v for k, v in r.items() if k not in ('D',)})
    pickle.dump({'results': results, 'stats': stats}, open('/tmp/fable/coll/stage2_p%d_corank%d%s.pkl' % (p, only_corank, ('_chunk%02d' % chunk) if nchunks > 1 else ''), 'wb'))
    print('done %.0fs' % (time.time() - t0))

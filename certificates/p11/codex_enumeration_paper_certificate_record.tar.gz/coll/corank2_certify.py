"""Per-branch certification of the points above a corank-2 special point.
Heuristic part (only to locate candidates): 2D truncated local series, generic linear change, Berkowitz resultant, Newton-polygon
descent.  Rigorous part: for each branch, a local field K (lfield.LField), a candidate point a* in O_K^d, and the strict DVR
Newton-Kantorovich condition v(F(a*)) > 2 v(det J(a*)) on the EXACT equations; then v(a_exact - a*) >= v(F) - v(det J).
Distinctness: branches differ in the valuation or the residue of the generic coordinate t, or are conjugates in a field that t
generates; completeness: sum of branch degrees equals the local length L."""
import numpy as np, sympy as sp, math, sys, pickle, time, itertools
sys.path.insert(0, '/tmp/fable/coll')
import local_analysis as la
from lfield import LField
try:
    sys.path.insert(0, '/home/amigita/projects/KS-260829'); sys.path.insert(0, '/tmp/ks-codex-series-deps')
    from codex_fast_series import PackedSer as _FastSer
except Exception:
    _FastSer = None
from fractions import Fraction

# ---------------------------------------------------------------- helpers on 2D jets (object arrays [i,j] <-> e1^i e2^j)
def linear_change(g, c, mod):
    """substitute e1 = t - c*e2 : returns jet in (t, e2) with the same square truncation (exact for polynomials, then truncated)."""
    E = g.shape[0]; out = np.zeros((E, E), dtype=object); out[...] = 0
    # (t - c e2)^i = sum_k C(i,k) t^{i-k} (-c e2)^k
    for i in range(E):
        for j in range(E):
            coef = int(g[i, j]) % mod
            if not coef: continue
            for k in range(i + 1):
                jj = j + k
                if jj >= E: continue
                out[i - k, jj] = (out[i - k, jj] + coef * math.comb(i, k) * pow(-c, k, mod)) % mod
    return out

def eval_jet_K(K, g, X1, X2):
    """evaluate a 2D jet at (X1, X2) in O_K."""
    E = g.shape[0]; acc = K.zero()
    P1 = [K.one()]; P2 = [K.one()]
    for i in range(1, E): P1.append(K.mul(P1[-1], X1)); P2.append(K.mul(P2[-1], X2))
    for i in range(E):
        for j in range(E):
            c = int(g[i, j]) % K.mod
            if c: acc = K.add(acc, K.scal(c, K.mul(P1[i], P2[j])))
    return acc

def eval_poly_K(K, coeffs, X):
    acc = K.zero(); P = K.one()
    for c in coeffs:
        acc = K.add(acc, K.scal(int(c), P)); P = K.mul(P, X)
    return acc

# ---------------------------------------------------------------- descent on the univariate eliminant R (heuristic)
def valp(v, ell, cap):
    v = int(v)
    if v == 0: return cap
    k = 0
    while v % ell == 0 and k < cap: v //= ell; k += 1
    return k

def factor_mod(phi, ell):
    """irreducible factors over F_ell of a polynomial with int coeffs (low->high): list of (coeff list monic, multiplicity)."""
    T = sp.Symbol('T'); P = sp.Poly(sum(int(c) * T**k for k, c in enumerate(phi)), T, modulus=ell)
    out = []
    for fac, mult in P.factor_list()[1]:
        cs = [int(fac.coeff_monomial(T**k)) % ell for k in range(fac.degree() + 1)]
        out.append((cs, mult))
    return out

def descend(R, ell, K, M_field, shift=0, scale=0, depth=0):
    """Branches of the small roots of R (ints mod ell^K), R already in the variable tau with eps1 = shift + ell^scale * tau.
    Returns list of dicts: {a, b, m (irreducible factor, monic int list), field: LField, eps1: element of field, degree}
    or {'flag': ...}."""
    mod = ell**K; R = [int(v) % mod for v in R]
    vals = [valp(c, ell, K) for c in R]
    L = next((k for k, v in enumerate(vals) if v == 0), None)
    if L is None or L == 0: return [{'flag': 'no small roots visible (L=%s) at depth %d' % (L, depth)}]
    pts = [(i, vals[i]) for i in range(L + 1)]; hull = [pts[0]]
    for pt in pts[1:]:
        while len(hull) >= 2:
            (x1, y1), (x2, y2) = hull[-2], hull[-1]; x3, y3 = pt
            if (y2 - y1) * (x3 - x1) >= (y3 - y1) * (x2 - x1): hull.pop()
            else: break
        hull.append(pt)
    branches = []
    for (i0, v0), (i1, v1) in zip(hull, hull[1:]):
        n_e = i1 - i0
        if v0 >= K: branches.append({'flag': 'unknown valuation at index %d (depth %d)' % (i0, depth)}); continue
        s = Fraction(v0 - v1, n_e); a_, b_ = s.numerator, s.denominator
        phi = [0] * (n_e // b_ + 1)
        for i in range(i0, i1 + 1):
            if (i - i0) % b_ == 0 and vals[i] == v0 - (i - i0) * a_ // b_: phi[(i - i0) // b_] = (R[i] // ell**vals[i]) % ell
        for m_fac, mult in factor_mod(phi, ell):
            f = len(m_fac) - 1
            if mult == 1:
                # leaf: tau^b = ell^a * T0, T0 a root of m_fac.  Eisenstein basis (Codex): a*s + b*t = 1, varpi = tau^s ell^t,
                # varpi^b = ell * T0^s, O_K = W[varpi], tau = T0^t varpi^a.
                s_, t_, _g = sp.gcdex(a_, b_); s_, t_ = int(s_), int(t_)
                T0 = ([0, 1] + [0] * (f - 2)) if f > 1 else [(-m_fac[0]) % ell]
                Kf0 = LField(ell, M_field, m_fac, 1, 1, [1])
                def wpow(x, k):
                    r = [1] + [0] * (f - 1)
                    base = list(x) if k >= 0 else Kf0.winv_unit(list(x))
                    for _ in range(abs(k)): r = Kf0.wmul(r, base)
                    return r
                Kf = LField(ell, M_field, m_fac, 1, b_, wpow(T0, s_))
                varpi = Kf.pi(); tau = Kf.from_w(wpow(T0, t_))
                for _ in range(a_): tau = Kf.mul(tau, varpi)
                eps1 = Kf.add(Kf.from_int(shift), Kf.scal(ell**scale, tau))
                branches.append({'a': a_, 'b': b_, 'm': m_fac, 'field': Kf, 'eps1': eps1, 'degree': f * b_, 'depth': depth,
                                 'tau_val': (a_, b_), 'residue_poly': m_fac})
            else:
                if b_ != 1 or f != 1:
                    branches.append({'flag': 'repeated edge root needing extension (slope %s, f=%d) at depth %d' % (s, f, depth)}); continue
                theta = (-m_fac[0]) % ell; s_ = a_
                # refine: tau = ell^s (theta + tau'), divide by ell^{v0}
                deg = len(R) - 1; h = [0] * (deg + 1)
                for i in range(deg + 1):
                    if R[i] == 0: continue
                    coef = R[i] * ell**(s_ * i)
                    for k in range(i + 1): h[k] += coef * math.comb(i, k) * theta**(i - k)
                assert all(hk % ell**v0 == 0 for hk in h)
                Knew = K - v0
                if Knew <= 1: branches.append({'flag': 'precision exhausted in descent (depth %d)' % depth}); continue
                h = [(hk // ell**v0) % ell**Knew for hk in h]
                sub = descend(h, ell, Knew, M_field, shift=shift + ell**scale * ell**s_ * theta, scale=scale + s_, depth=depth + 1)
                branches += sub
    return branches


def substitute_eps1(g, ell, s, theta, mod):
    """e1 = ell^s (theta + tau): jet in (tau, e2), then divide out the largest common power of ell (returned)."""
    E = g.shape[0]; out = np.zeros((E, E), dtype=object); out[...] = 0
    for i in range(E):
        for j in range(E):
            c = int(g[i, j]) % mod
            if not c: continue
            base = c * ell**(s * i)
            for k in range(i + 1):
                out[k, j] = (out[k, j] + base * math.comb(i, k) * theta**(i - k)) % mod
    # common power of ell
    vmin = None
    for i in range(E):
        for j in range(E):
            c = int(out[i, j]) % mod
            if c:
                v = valp(c, ell, 10**6)
                vmin = v if vmin is None else min(vmin, v)
    if vmin is None: return out, 0
    out2 = np.zeros((E, E), dtype=object); out2[...] = 0
    for i in range(E):
        for j in range(E):
            c = int(out[i, j]) % mod
            out2[i, j] = (c // ell**vmin) % (mod // ell**vmin) if c else 0
    return out2, vmin

def _divisible_by_e2(g, mod):
    return not any(int(g[i, 0]) % mod for i in range(g.shape[0]))

def _shift_e2(g, mod):
    E = g.shape[0]; out = np.zeros((E, E), dtype=object); out[...] = 0
    out[:, :E - 1] = g[:, 1:]
    return out

def branches_2d(g1, g2, ell, K, E, S, M_field, shift=0, scale=0, depth=0):
    """Branches from the first-level Newton polygon of R = Res_{e2}(g1, g2); refinement is done on the 2D jets.
    If g1 or g2 is divisible by e2 (to precision), the local scheme splits: {e2 = 0} n {other = 0} (univariate in t) plus
    {g/e2 = 0} n {other = 0} (recursive); the e2 = 0 component is returned as branches with 'e2_exact_zero'."""
    mod = ell**K
    for g_div, g_oth, which in ((g1, g2, 'g1'), (g2, g1, 'g2')):
        if _divisible_by_e2(g_div, mod):
            branches = []
            # component e2 = 0: univariate polynomial g_oth(t, 0) in t
            poly_t = [int(g_oth[i, 0]) % mod for i in range(E)]
            sub = descend(poly_t, ell, K, M_field, shift=shift, scale=scale, depth=depth)
            for br in sub:
                if 'flag' not in br:
                    br['e2_exact_zero'] = True; br['g1'] = g1; br['g2'] = g2; br['scale'] = scale; br['shift'] = shift
            branches += sub
            # residual component
            gq = _shift_e2(g_div, mod)
            sub2, _ = branches_2d(gq, g_oth, ell, K, E, S, M_field, shift=shift, scale=scale, depth=depth) if any(int(x) % mod for x in gq.ravel()) else ([], None)
            branches += sub2
            return branches, None
    R = la.resultant_in_second(g1, g2, S, ell, K, T=E)
    R = [int(v) % mod for v in R]; vals = [valp(c, ell, K) for c in R]
    # the two jets may share a factor modulo a power of ell (then R is divisible by that power): renormalize, roots unchanged
    kmin = min(vals)
    if 0 < kmin < K:
        R = [(c // ell**kmin) % ell**(K - kmin) for c in R]; K = K - kmin; mod = ell**K; vals = [valp(c, ell, K) for c in R]
    L = next((k for k, v in enumerate(vals) if v == 0), None)
    if L is None or L == 0: return [{'flag': 'no small roots visible (L=%s) at depth %d' % (L, depth)}], L
    pts = [(i, vals[i]) for i in range(L + 1)]; hull = [pts[0]]
    for pt in pts[1:]:
        while len(hull) >= 2:
            (x1, y1), (x2, y2) = hull[-2], hull[-1]; x3, y3 = pt
            if (y2 - y1) * (x3 - x1) >= (y3 - y1) * (x2 - x1): hull.pop()
            else: break
        hull.append(pt)
    branches = []
    for (i0, v0), (i1, v1) in zip(hull, hull[1:]):
        n_e = i1 - i0
        if v0 >= K: branches.append({'flag': 'unknown valuation at index %d (depth %d)' % (i0, depth)}); continue
        s = Fraction(v0 - v1, n_e); a_, b_ = s.numerator, s.denominator
        phi = [0] * (n_e // b_ + 1)
        for i in range(i0, i1 + 1):
            if (i - i0) % b_ == 0 and vals[i] == v0 - (i - i0) * a_ // b_: phi[(i - i0) // b_] = (R[i] // ell**vals[i]) % ell
        for m_fac, mult in factor_mod(phi, ell):
            f = len(m_fac) - 1
            if mult == 1:
                s_, t_, _g = sp.gcdex(a_, b_); s_, t_ = int(s_), int(t_)
                T0 = ([0, 1] + [0] * (f - 2)) if f > 1 else [(-m_fac[0]) % ell]
                Kf0 = LField(ell, M_field, m_fac, 1, 1, [1])
                def wpow(x, k):
                    r = [1] + [0] * (f - 1)
                    base = list(x) if k >= 0 else Kf0.winv_unit(list(x))
                    for _ in range(abs(k)): r = Kf0.wmul(r, base)
                    return r
                Kf = LField(ell, M_field, m_fac, 1, b_, wpow(T0, s_))
                varpi = Kf.pi(); tau = Kf.from_w(wpow(T0, t_))
                for _ in range(a_): tau = Kf.mul(tau, varpi)
                eps1 = Kf.add(Kf.from_int(shift), Kf.scal(ell**scale, tau))
                branches.append({'a': a_, 'b': b_, 'm': m_fac, 'field': Kf, 'eps1': eps1, 'degree': f * b_, 'depth': depth,
                                 'residue_poly': m_fac, 'g1': g1, 'g2': g2, 'scale': scale, 'shift': shift})
            else:
                if b_ != 1 or f != 1:
                    branches.append({'flag': 'repeated edge root needing extension (slope %s, f=%d) at depth %d' % (s, f, depth)}); continue
                theta = (-m_fac[0]) % ell; s_ = a_
                g1s, v1s = substitute_eps1(g1, ell, s_, theta, mod); g2s, v2s = substitute_eps1(g2, ell, s_, theta, mod)
                Knew = K - max(v1s, v2s)
                if Knew <= 2: branches.append({'flag': 'precision exhausted at 2D refinement (depth %d)' % depth}); continue
                # both jets must live modulo the same ell^Knew: reduce
                g1s = g1s % ell**Knew; g2s = g2s % ell**Knew
                sub, _ = branches_2d(g1s, g2s, ell, Knew, E, S, M_field, shift=shift + ell**scale * ell**s_ * theta, scale=scale + s_, depth=depth + 1)
                branches += sub
    return branches, L

# ---------------------------------------------------------------- residue field roots, second coordinate
def residue_roots(K, coeffs_K):
    """roots in F_{l^f} of the reduction of a polynomial with O_K coefficients whose reductions are given as W-lists (row 0)."""
    ell, f = K.ell, K.f; zeta = sp.Symbol('z')
    m = sp.Poly(sum(c * zeta**k for k, c in enumerate(K.m)), zeta, modulus=ell)
    elems = list(itertools.product(range(ell), repeat=f))
    def wmul_mod(x, y):
        return [int(c) % ell for c in K.wmul([int(v) for v in x], [int(v) for v in y])]
    roots = []
    for e in elems:
        acc = [0] * f; P = [1] + [0] * (f - 1)
        for c in coeffs_K:
            acc = [(p + q) % ell for p, q in zip(acc, wmul_mod(c, P))]; P = wmul_mod(P, list(e))
        if all(v == 0 for v in acc): roots.append(list(e))
    return roots

def find_eps2(K, g1, g2, eps1, maxiter=40):
    """small roots eps2 in O_K of g1(eps1, .) (Newton polygon over K + Newton refinement); keep those with g2 small too."""
    E = g1.shape[0]
    P1 = [K.one()]
    for i in range(1, E): P1.append(K.mul(P1[-1], eps1))
    coeffs = []
    for j in range(E):
        acc = K.zero()
        for i in range(E):
            c = int(g1[i, j]) % K.mod
            if c: acc = K.add(acc, K.scal(c, P1[i]))
        coeffs.append(acc)
    vals = [K.val(c) for c in coeffs]; cap = K.b * K.M
    L2 = next((k for k, v in enumerate(vals) if v == 0), None)
    if L2 is None or L2 == 0: return [], ['no small eps2 root visible (L2=%s)' % L2]
    if vals[0] >= cap:
        # constant coefficient vanishes to precision: eps2 = 0 is a candidate; the cofactor may have further small roots
        zero = K.zero(); g2v = eval_jet_K(K, g2, eps1, zero)
        cands0 = [(zero, K.val(g2v))]
        sub_coeffs = coeffs[1:]
        # recurse on the cofactor via a synthetic jet-free path: rebuild candidates from the shifted coefficient list
        sub_cands, sub_flags = _eps2_from_coeffs(K, sub_coeffs, g1, g2, eps1, maxiter)
        return cands0 + sub_cands, sub_flags
    return _eps2_from_coeffs(K, coeffs, g1, g2, eps1, maxiter)

def _eps2_from_coeffs(K, coeffs, g1, g2, eps1, maxiter):
    E = g1.shape[0]
    vals = [K.val(c) for c in coeffs]; cap = K.b * K.M
    L2 = next((k for k, v in enumerate(vals) if v == 0), None)
    if L2 is None or L2 == 0: return [], ([] if L2 == 0 else ['no unit coefficient in eps2 cofactor'])
    pts = [(i, vals[i]) for i in range(L2 + 1)]; hull = [pts[0]]
    for pt in pts[1:]:
        while len(hull) >= 2:
            (x1, y1), (x2, y2) = hull[-2], hull[-1]; x3, y3 = pt
            if (y2 - y1) * (x3 - x1) >= (y3 - y1) * (x2 - x1): hull.pop()
            else: break
        hull.append(pt)
    i0, j0 = 1, 0
    cands = []; flags = []
    for (a0, v0), (a1, v1) in zip(hull, hull[1:]):
        n_e = a1 - a0
        if v0 >= cap: flags.append('unknown eps2 valuation'); continue
        if (v0 - v1) % n_e: flags.append('fractional eps2 slope %d/%d (extension needed)' % (v0 - v1, n_e)); continue
        sig = (v0 - v1) // n_e                       # eps2 = varpi^sig * unit
        # varpi^sig as an element: pi^{i0 sig} * l^{j0 sig} (j0 may be negative -> only if divisible; use divide by l)
        varpi_s = K.one(); pi = K.pi()
        for _ in range(abs(i0 * sig)): varpi_s = K.mul(varpi_s, pi) if i0 * sig > 0 else varpi_s
        if i0 * sig < 0: flags.append('negative pi power in uniformizer (unsupported)'); continue
        if j0 * sig >= 0: varpi_s = K.scal(K.ell**(j0 * sig), varpi_s)
        else:
            try: varpi_s, _ = K.divide(varpi_s, K.from_int(K.ell**(-j0 * sig)))
            except AssertionError: flags.append('uniformizer power not integral'); continue
        # edge polynomial over F_{l^f}: coefficient of eps2^k on the edge -> (c_k / varpi^{v_k}) mod pi
        edge = []
        for k in range(a0, a1 + 1):
            vk = v0 - (k - a0) * sig
            if vals[k] == vk:
                w = K.one()
                for _ in range(i0 * vk): w = K.mul(w, pi)
                if j0 * vk >= 0: w = K.scal(K.ell**(j0 * vk), w)
                else: w, _ = K.divide(w, K.from_int(K.ell**(-j0 * vk)))
                q, _ = K.divide(coeffs[k], w)
                edge.append([int(x) % K.ell for x in q[0]])
            else: edge.append([0] * K.f)
        for theta in residue_roots(K, edge):
            th = K.from_w(theta); e2 = K.mul(varpi_s, th)
            # Newton refinement on g1(eps1, .)
            dg = np.zeros_like(g1)
            for j in range(1, E): dg[:, j - 1] = (g1[:, j] * j) % K.mod
            ok = True
            for it in range(maxiter):
                fval = eval_jet_K(K, g1, eps1, e2)
                if K.is_zero(fval): break
                dval = eval_jet_K(K, dg, eps1, e2)
                if K.val(fval) < K.val(dval): ok = False; break
                step, _ = K.divide(fval, dval); e2 = K.sub(e2, step)
            if not ok: flags.append('Newton for eps2 left the integral domain'); continue
            g2v = eval_jet_K(K, g2, eps1, e2)
            cands.append((e2, K.val(g2v)))
    return cands, flags

# ---------------------------------------------------------------- Berkowitz over K and the certificate
def berkowitz_K(K, Mx):
    n = len(Mx); Z = K.zero(); ONE = K.one()
    def berk(Mx):
        n = len(Mx)
        if n == 1: return [ONE, K.sub(Z, Mx[0][0])]
        a = Mx[0][0]; R = Mx[0][1:]; C = [row[0] for row in Mx[1:]]; Sub = [row[1:] for row in Mx[1:]]
        diags = [C]
        for i in range(n - 2):
            prev = diags[-1]; nxt = []
            for r in range(n - 1):
                acc = Z
                for c_ in range(n - 1): acc = K.add(acc, K.mul(Sub[r][c_], prev[c_]))
                nxt.append(acc)
            diags.append(nxt)
        dvals = [ONE, K.sub(Z, a)]
        for dvec in diags:
            acc = Z
            for c_ in range(n - 1): acc = K.add(acc, K.mul(R[c_], dvec[c_]))
            dvals.append(K.sub(Z, acc))
        sub = berk(Sub); out = []
        for i in range(n + 1):
            acc = Z
            for j in range(n):
                if j <= i: acc = K.add(acc, K.mul(dvals[i - j], sub[j]))
            out.append(acc)
        return out
    vec = berk(Mx)
    return vec[-1] if n % 2 == 0 else K.sub(Z, vec[-1])

def eval_G_K(K, terms, avec):
    d = len(avec); maxdeg = max(max(m) for m in terms)
    powers = [[K.one()] for _ in range(d)]
    for j in range(d):
        for e in range(1, maxdeg + 1): powers[j].append(K.mul(powers[j][-1], avec[j]))
    acc = K.zero()
    for mono, (num, den) in terms.items():
        c = (num * pow(den, -1, K.mod)) % K.mod
        t = K.from_int(c)
        for j, e in enumerate(mono):
            if e: t = K.mul(t, powers[j][e])
        acc = K.add(acc, t)
    return acc

def newton_kantorovich(K, a_star, G, Gd, max_steps=6, verbose=False):
    """strict DVR condition v(F_i(a)) > 2 v(det J(a)) for all i; refine by Newton if not yet satisfied."""
    d = len(a_star); a = [x.copy() for x in a_star]; hist = []
    for step in range(max_steps + 1):
        F = [eval_G_K(K, g, a) for g in G]
        J = [[eval_G_K(K, Gd[r][j], a) for j in range(d)] for r in range(d)]
        delta = berkowitz_K(K, J); vd = K.val(delta); vF = min(K.val(f) for f in F)
        hist.append((vF, vd))
        if verbose: print('     NK step %d: v(F)=%s v(det J)=%s' % (step, vF, vd), flush=True)
        if vd >= K.b * K.M: return {'ok': False, 'reason': 'det J vanishes to precision', 'hist': hist}
        if vF > 2 * vd:
            # two extra Newton updates for margin (each re-checked); keep the best certified state
            best = {'ok': True, 'vF': vF, 'vdelta': vd, 'radius': vF - vd, 'hist': hist, 'a': a}
            for extra in range(2):
                try:
                    adjF = []
                    for i in range(d):
                        Mi = [[J[r][c] if c != i else F[r] for c in range(d)] for r in range(d)]
                        adjF.append(berkowitz_K(K, Mi))
                    a2 = [K.sub(a[i], K.divide(adjF[i], delta)[0]) for i in range(d)]
                    F2 = [eval_G_K(K, g, a2) for g in G]; J2 = [[eval_G_K(K, Gd[r][j], a2) for j in range(d)] for r in range(d)]
                    d2 = berkowitz_K(K, J2); vd2 = K.val(d2); vF2 = min(K.val(f) for f in F2)
                    if vd2 < K.b * K.M and vF2 > 2 * vd2 and vF2 - vd2 > best['radius']:
                        best = {'ok': True, 'vF': vF2, 'vdelta': vd2, 'radius': vF2 - vd2, 'hist': hist + [(vF2, vd2)], 'a': a2}
                        a, F, J, delta = a2, F2, J2, d2
                    else: break
                except AssertionError:
                    break
            return best
        if step == max_steps: break
        # Newton step a <- a - adj(J) F / delta   (Cramer via Berkowitz)
        adjF = []
        for i in range(d):
            Mi = [[J[r][c] if c != i else F[r] for c in range(d)] for r in range(d)]
            adjF.append(berkowitz_K(K, Mi))
        try:
            new = []
            for i in range(d):
                q, lost = K.divide(adjF[i], delta); new.append(K.sub(a[i], q))
            a = new
        except AssertionError:
            return {'ok': False, 'reason': 'Newton step not integral', 'hist': hist}
    return {'ok': False, 'reason': 'condition not reached', 'hist': hist}

# ---------------------------------------------------------------- driver for one corank-2 point
def certify_corank2_point(st, a0, presentations, K_ser=10, E_ser=12, M_field=24, c_list=(0, 3, 1, 5, 7), verbose=False):
    best = None
    for c_change in c_list:
        out = _certify_corank2_point(st, a0, presentations, K_ser, E_ser, M_field, c_change, verbose)
        out['c_change'] = c_change
        if out.get('complete'): return out
        if best is None or out.get('certified_degree', 0) > best.get('certified_degree', 0): best = out
    return best

def _certify_corank2_point(st, a0, presentations, K_ser, E_ser, M_field, c_change, verbose):
    ell, d = st['ell'], st['p'] - 1; mod = ell**K_ser
    Gmod = [{m: (num * pow(den, -1, ell)) % ell for m, (num, den) in g.items()} for g in st['G']]
    def jac_mod(a0):
        J = [[0] * d for _ in range(d)]
        for r, g in enumerate(Gmod):
            for mono, c in g.items():
                for j, e in enumerate(mono):
                    if e:
                        v = c * e
                        for jj, ee in enumerate(mono): v = v * pow(int(a0[jj]), ee - 1 if jj == j else ee, ell)
                        J[r][j] = (J[r][j] + v) % ell
        return J
    J = jac_mod(a0); pr, pc, fc, ker = la.rank_pivots(J, ell); assert len(fc) == 2
    SerCls = _FastSer if _FastSer is not None else la.Ser
    Ev = la.Evaluator(d, ell, K_ser, SerCls(2, E_ser, mod))
    g1, g2 = la.local_series(Ev, Ev.S, a0, pr, pc, fc, ell, K_ser, J); avec = la.local_series.last_avec
    g1 = np.array(g1, dtype=object); g2 = np.array(g2, dtype=object); avec = [np.array(v, dtype=object) for v in avec]
    # generic linear change e1 = t - c e2 (t is then the generic coordinate)
    g1t, g2t = linear_change(g1, c_change, mod), linear_change(g2, c_change, mod)
    avect = [linear_change(v, c_change, mod) for v in avec]
    branches, L = branches_2d(g1t, g2t, ell, K_ser, E_ser, Ev.S, M_field)
    out = {'L_from_R': L, 'npres': len(presentations), 'branches': [], 'flags': []}
    Gd = [[la.__dict__.get('derivative_terms_rat', None) and None for j in range(d)] for r in range(d)]
    from hensel_certificate import derivative_terms_rat
    Gd = [[derivative_terms_rat(g, j) for j in range(d)] for g in st['G']]
    total_degree = 0
    seen_data = set()
    for br in branches:
        if 'flag' in br: out['flags'].append(br['flag']); continue
        key = (br.get('shift'), br.get('scale'), br['a'], br['b'], tuple(br['residue_poly']), bool(br.get('e2_exact_zero')))
        if key in seen_data: out['flags'].append('duplicate branch data skipped'); continue
        seen_data.add(key)
        Kf = br['field']; t_val = br['eps1']
        # in the branch's own (substituted, rescaled) jets the first variable is tau with t = shift + ell^scale * tau
        tau_val = Kf.pi() if br['a'] == 1 else None
        varpi = Kf.pi(); tau_val = Kf.one()
        # recover tau from eps1: eps1 = shift + ell^scale * tau  ->  tau = (eps1 - shift) / ell^scale (exact division)
        diff = Kf.sub(t_val, Kf.from_int(br['shift']))
        tau_val, _ = Kf.divide(diff, Kf.from_int(ell**br['scale'])) if br['scale'] > 0 else (diff, 0)
        if br.get('e2_exact_zero'):
            cands, fl = [(Kf.zero(), Kf.b * Kf.M)], []
        else:
            cands, fl = find_eps2(Kf, br['g1'], br['g2'], tau_val)
        out['flags'] += fl
        if not cands: out['flags'].append('no eps2 candidate for a branch'); continue
        cands.sort(key=lambda c: -c[1])                    # smallest g2 first
        # ONE record per branch: a branch is a Galois orbit of t-values and is credited with its degree once.  Different
        # second-coordinate candidates may converge (after Newton drift) to conjugate points of the same orbit, so they must not
        # be counted separately; the first certified candidate represents the branch.
        chosen = None
        for e2, v_g2 in cands[:4]:
            a_star = [eval_jet_K(Kf, v, t_val, e2) for v in avect]
            nk_try = newton_kantorovich(Kf, a_star, st['G'], Gd, verbose=verbose)
            if nk_try['ok']: chosen = (e2, v_g2, nk_try); break
        if chosen is None:
            e2, v_g2 = cands[0]; a_star = [eval_jet_K(Kf, v, t_val, e2) for v in avect]; chosen = (e2, v_g2, newton_kantorovich(Kf, a_star, st['G'], Gd, verbose=verbose))
        certified_list = [chosen]
        for e2, v_g2, nk in certified_list:
            rec = {'a': br['a'], 'b': br['b'], 'f': Kf.f, 'residue_poly': br['residue_poly'], 'degree': br['degree'], 'depth': br['depth'],
                   'v_g2_at_candidate': v_g2, 'ok': nk['ok'], 'nk': {k: v for k, v in nk.items() if k != 'a'}}
            # separation check: the certified ball must be smaller than the scale of t: radius > v(t) so residue/valuation of t are exact
            if nk['ok']:
                a_c = nk['a']
                # separating coordinate of the CERTIFIED point: t = eps1 + c*eps2 with eps_i = a[fc_i] - a0[fc_i]
                e1c = Kf.sub(a_c[fc[0]], Kf.from_int(int(a0[fc[0]]))); e2c = Kf.sub(a_c[fc[1]], Kf.from_int(int(a0[fc[1]])))
                t_c = Kf.add(e1c, Kf.scal(c_change, e2c))
                dev = Kf.sub(t_c, Kf.from_int(br['shift']))
                v_dev = Kf.val(dev)
                rec['v_dev'] = v_dev; rec['radius'] = nk['radius']
                # residue check: tau = dev / ell^scale, tau^b / ell^a must be a unit reducing to the branch root T0 (mod varpi)
                residue_ok = False
                try:
                    tau_c, _ = Kf.divide(dev, Kf.from_int(ell**br['scale'])) if br['scale'] > 0 else (dev, 0)
                    pw = Kf.one()
                    for _ in range(br['b']): pw = Kf.mul(pw, tau_c)
                    unit, _ = Kf.divide(pw, Kf.from_int(ell**br['a']))
                    T0 = ([0, 1] + [0] * (Kf.f - 2)) if Kf.f > 1 else [(-br['residue_poly'][0]) % ell]
                    residue_ok = (Kf.val(unit) == 0) and all((int(x) - int(y)) % ell == 0 for x, y in zip(unit[0], T0))
                except AssertionError:
                    residue_ok = False
                rec['residue_preserved'] = residue_ok
                rec['separates'] = (nk['radius'] > v_dev) and residue_ok
                if rec['separates']: total_degree += br['degree']
                # export for independent checking
                rec['field_def'] = {'ell': ell, 'm': Kf.m, 'b': Kf.b, 'u': Kf.u, 'M': Kf.M}
                rec['a_certified'] = [[[int(x) for x in row] for row in coord] for coord in a_c]
                rec['vF'] = nk['vF']; rec['vdelta'] = nk['vdelta']; rec['shift'] = br['shift']; rec['scale'] = br['scale']; rec['c_change'] = c_change
            out['branches'].append(rec)
    out['certified_degree'] = total_degree
    # completeness: the certified, pairwise-distinct branches exhaust the local length (= number of presentations, rigorous by the
    # flatness total); remaining candidate flags then concern spurious candidates, which cannot be points
    out['complete'] = (total_degree == len(presentations))
    out['spurious_candidate_flags'] = out['flags'] if out['complete'] else []
    return out

if __name__ == '__main__' and sys.argv[1] != 'batch':
    p = int(sys.argv[1]); nmax = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    st = pickle.load(open('/tmp/fable/coll/stage1_p%d.pkl' % p, 'rb'))
    pts = [s_ for s_ in st['singular'] if s_[1] == 2][:nmax]
    for a0, cr, pres in pts:
        t0 = time.time()
        out = certify_corank2_point(st, a0, pres, verbose=('-v' in sys.argv))
        print('point npres=%d L_R=%s certified_degree=%s complete=%s flags=%s  (%.1fs)' % (len(pres), out['L_from_R'], out.get('certified_degree'), out.get('complete'), out['flags'], time.time() - t0), flush=True)
        for br in out['branches']: print('    branch a/b=%d/%d f=%d deg=%d depth=%d ok=%s sep=%s nk=%s' % (br['a'], br['b'], br['f'], br['degree'], br['depth'], br['ok'], br.get('separates'), br['nk'].get('hist')), flush=True)


def run_batch(p, chunk, nchunks, K_ser=10, E_ser=12, M_field=24):
    st = pickle.load(open('/tmp/fable/coll/stage1_p%d.pkl' % p, 'rb'))
    pts = [s_ for s_ in st['singular'] if s_[1] == 2][chunk::nchunks]
    results = []; t0 = time.time()
    for idx, (a0, cr, pres) in enumerate(pts):
        try:
            out = certify_corank2_point(st, a0, pres, K_ser=K_ser, E_ser=E_ser, M_field=M_field)
        except Exception as e:
            out = {'error': repr(e), 'complete': False, 'npres': len(pres)}
        out['point'] = [int(v) for v in a0]; out['npres'] = len(pres)
        for br in out.get('branches', []):
            br.pop('field', None)
        results.append(out)
        if (idx + 1) % 5 == 0:
            print('  %d/%d points, %.0fs, complete %d' % (idx + 1, len(pts), time.time() - t0, sum(1 for r in results if r.get('complete'))), flush=True)
    pickle.dump(results, open('/tmp/fable/coll/corank2_p%d_chunk%03d.pkl' % (p, chunk), 'wb'))
    print('chunk %d done: %d points, complete %d, %.0fs' % (chunk, len(results), sum(1 for r in results if r.get('complete')), time.time() - t0), flush=True)

if __name__ == '__main__' and len(sys.argv) > 3 and sys.argv[1] == 'batch':
    run_batch(int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]))

"""Independent re-derivation of the prime-index congruence (plan Sec. 2.1, eq. 5) and the
gap-2 factorisation at p=11, l=19 (plan Sec. 6, eq. 16). Nothing here imports Codex's code."""
import sympy as sp, math, time
x, n = sp.symbols('x n')
Qs, Ds = sp.symbols('Q D')

def faulhaber(k):  # sum_{j=1}^{n-1} j^k as a polynomial in n
    return sp.expand((sp.bernoulli(k + 1, n) - sp.bernoulli(k + 1, 0)) / (k + 1))

def H_discrete(A_coeffs):  # A_coeffs[i] = coefficient of x^i; returns Poly in x of sum_{j=1}^{n-1} A(j)A(n-j)
    d = len(A_coeffs) - 1
    F = [faulhaber(k) for k in range(2 * d + 1)]; F[0] = F[0] - 1  # drop the j=0 term
    H = 0
    for a in range(d + 1):
        for b in range(d + 1):
            term = sum(sp.binomial(b, i) * n**(b - i) * (-1)**i * F[a + i] for i in range(b + 1))
            H += A_coeffs[a] * A_coeffs[b] * term
    return sp.Poly(sp.expand(H).subs(n, x), x)

def reduce_mod(expr, params, ell):  # rational-coefficient polynomial in x and params -> integer coefficients mod ell
    P = sp.Poly(sp.expand(expr), x, *params)
    out = 0
    for mono, q in P.terms():
        num, den = sp.fraction(sp.Rational(q))
        assert den % ell != 0, ('non-integral at', ell, mono, q)
        r = (num * pow(den, -1, ell)) % ell
        if r:
            out += r * x**mono[0] * sp.prod([p**e for p, e in zip(params, mono[1:])])
    return sp.expand(out)

def dressing(d):
    params = list(sp.symbols('a1:%d' % (d + 1)))
    A = x**d + sum(params[i - 1] * x**(d - i) for i in range(1, d + 1))
    coeffs = [sp.Poly(A, x).coeff_monomial(x**i) for i in range(d + 1)]
    return params, A, coeffs

# 1. operator definition vs discrete convolution at p=3: v=A(D)Q, DQ=Q(1-Q); claim v^2 = -H_A(D) Q
def apply_D(f):  # D acting on polynomials in Q
    return sp.expand(sp.diff(f, Qs) * Qs * (1 - Qs))
def apply_op(poly_in_D, f):
    out, g = 0, f
    for c in sp.Poly(poly_in_D, Ds).all_coeffs()[::-1]:
        out += c * g; g = apply_D(g)
    return sp.expand(out)
params, A, coeffs = dressing(2)
v = apply_op(A.subs(x, Ds), Qs)
H = H_discrete(coeffs)
lhs = sp.expand(v**2 + apply_op(H.as_expr().subs(x, Ds), Qs))
print('p=3 operator identity v^2 = -H_A(D)Q :', lhs == 0)

# 2. prime-index congruence for l = 5, 7, 11, 13 (p = 3, 4, 6, 7)
for ell in [5, 7, 11, 13]:
    t = time.time(); d = (ell - 1) // 2
    params, A, coeffs = dressing(d)
    H = H_discrete(coeffs)
    R = reduce_mod(ell * H.as_expr(), params, ell)
    u = (math.factorial(d)**2 * pow(math.factorial(ell - 1), -1, ell)) % ell
    diff = reduce_mod(R - u * (x**ell - x), params, ell)
    print('l=%d p=%d: l*H_A == u(x^l - x) mod l with u=%d, (-1)^d mod l=%d : %s  (%.1fs)'
          % (ell, d + 1, u, (-1)**d % ell, diff == 0, time.time() - t))

# 3. gap-2 factorisation at p=11, l=19
t = time.time(); ell, d = 19, 10
params, A, coeffs = dressing(d)
H = H_discrete(coeffs)
R = reduce_mod(ell * H.as_expr(), params, ell)
u = (ell * math.factorial(d)**2 * sp.Rational(1, math.factorial(2 * d + 1)))
u = (sp.fraction(u)[0] * pow(int(sp.fraction(u)[1]), -1, ell)) % ell
a1, a2 = params[0], params[1]
S = x**2 + 8 * a1 * x + 8 * a1**2 - 16 * a2
diff = reduce_mod(R - u * (x**ell - x) * S, params, ell)
print('l=19 p=11: 19*H_A == u (x^19 - x)(x^2+8a1x+8a1^2-16a2) mod 19, u=%d : %s  (%.1fs)' % (u, diff == 0, time.time() - t))
print('   independence: R depends only on', sorted(str(s) for s in sp.Poly(R, x).free_symbols), '; -16 mod 19 =', (-16) % 19)

# 4. the singular modular point A0 = prod_{j=0}^{9} (x-j) mod 19
A0 = sp.Poly(sp.prod([x - j for j in range(10)]), x, modulus=19)
c = A0.all_coeffs()
a1v, a2v = int(c[1]) % 19, int(c[2]) % 19
S0 = sp.Poly(S.subs({a1: a1v, a2: a2v}), x, modulus=19)
print('A0 coefficients a1=%d a2=%d ; S(A0) = %s ; gcd(A0,S) = %s' % (a1v, a2v, S0.as_expr(), sp.gcd(A0, S0).as_expr()))

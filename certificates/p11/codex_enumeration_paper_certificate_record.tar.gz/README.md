# Enumeration paper — author handoff

Prepared 3 September 2026. This is a manuscript and source package, not an arXiv submission.

## Read first

- `codex_enumeration_paper.pdf` is the readable paper.
- `codex_enumeration_paper.tex` and `codex_enumeration_paper.bib` are the editable sources.
- `codex_enumeration_paper_arxiv.tar.gz` is the small TeX-source submission bundle.
- `codex_enumeration_paper_evidence.json` records the scope, provenance, and checks of the computational assertions.
- `codex_enumeration_paper_certificate_record.tar.gz` preserves the larger existing certificate record separately. It is not a new global replay or a turnkey installation.

## The mathematical scope

The counted objects are normalized pairs `(A, P)` as the differential operator varies, not solutions of one prescribed equation. The one-pole rational-exponential sector is explicitly defined; elliptic and multi-pole profiles are not counted.

The paper proves:

1. The equivalence between matching a profile and polynomial divisibility `A | H_A`.
2. A universal upper bound on the sum of the multiplicities of isolated points, and equality with the binomial coefficient under the stated continuous-convolution rigidity condition `(NI_p)`.
3. The unconditional exact count and multiplicity one when `2p - 1` is prime, with finite-field labels after an embedding is chosen.
4. The count with multiplicity when `q = 2p - 3 > 3` is prime and `q` is neither 7 nor 17. This includes the degree calculations for `p = 8, 11, 13`.

The unrestricted count and unrestricted multiplicity-one statement are **conjectures**. Neither is promoted to a theorem. The finite completed cases through `p = 12` are supported by the prime theorem and exact computational certificates at `p = 5, 8, 11`. At `p = 13`, total multiplicity is proved; simplicity remains open in the record used here.

## Readability and review

The argument starts from the differential equation and polynomial division. Multiplicity, the weighted degree calculation, and the elementary lifting argument are explained in the text. The complete `p = 3` calculation is worked out by hand.

Fable reviewed two drafts, independently rechecked the order-three formulas and the nearby-prime argument, and identified the need to justify characteristic-zero finiteness separately from the count of lifted points. That correction is included. The editorial exchange is not a mathematical certificate or a substitute for human review.

## Small checks and compilation

The symbolic checker requires Python 3.8 or newer and SymPy. It checks exact identities and small finite-field examples; it does not infer an all-order theorem from them.

```sh
python3 codex_enumeration_paper_checks.py
tectonic --keep-logs --keep-intermediates codex_enumeration_paper.tex
```

The source bundle includes the generated `.bbl`, so it can also be compiled with standard LaTeX tools:

```sh
pdflatex codex_enumeration_paper.tex
bibtex codex_enumeration_paper
pdflatex codex_enumeration_paper.tex
pdflatex codex_enumeration_paper.tex
```

In the source bundle, small programs and computation records are under `anc/`. Run the checker there with `python3 anc/codex_enumeration_paper_checks.py`.

The included `anc/p5_matching.sing` is a self-contained Singular input for the rational `p = 5` Gröbner calculation. `anc/p8_matching.sing` and its saved transcript document the modular `p = 8` calculation. Replay with `Singular -q FILE.sing`; `p = 8` is substantially slower. A transcript, hash, or summary alone is not a proof that the underlying calculation was executed correctly. The evidence manifest distinguishes the freshly replayed `p = 5` calculation from the inspected older `p = 8` and `p = 11` records.

## Larger certificate record

The separate archive preserves the existing exact `p = 11` data, the local-lifting justification, the scripts that produced the certificates, and the independent corank-two audit outputs. The three subtotals are 207153, 97971, and 47592, totalling 352716. The no-infinity/total-multiplicity argument needed to exhaust the solution set is proved in the paper itself.

The archived programs retain their historical paths. They need path configuration before replay on another machine. Their third-party dependencies are SymPy 1.13.3, NumPy 1.24.4, python-flint 0.8.0, and gmpy2 2.2.2; the companion archive contains `requirements.txt`. The recorded computations used Python 3.8.10, with Python 3.11.13 for the local-field subprocess. The old `/tmp/ks-codex-series-deps` path supplied gmpy2, not an additional project helper. The archive includes the separately imported `audit_congruence.py` under `fable_root/`.

Full replay can take many CPU-hours. Pickle data should only be deserialized from a trusted copy; use the manifest hashes to check provenance. The archive is a preservation snapshot, not a newly validated portable reproduction pipeline. Third-party packages and binaries are not redistributed in it.

## Before submission

- Supply the actual human authors, affiliations, contact details, and any acknowledgements or tool-use disclosure. The author field is intentionally blank; no authorship or endorsement is inferred.
- Have a human mathematician review the argument, particularly the finite-cover multiplicity calculation and the no-infinity step.
- Arrange a durable public deposit for the larger certificate archive and cite that deposit in the paper. No public DOI or availability is invented here.
- Decide whether to retain the reported larger computational results before that deposit is ready. They are not needed for the prime-index theorem.
- Perform the final priority and bibliography review. The manuscript credits Eremenko and Demina–Kudryashov and does not claim to have invented the logistic representation or a universal classification of meromorphic waves.
- Inspect the PDF generated by the actual submission service after uploading the sources.

The earlier all-order proof program and its automatic wakeup timer remain paused. Preparing this manuscript does not restart them.
